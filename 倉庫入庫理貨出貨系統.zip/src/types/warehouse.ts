export type UserRole = 'admin' | 'manager' | 'operator';

export interface User {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  department: string;
  active: boolean;
  createdAt: string;
}

export type RecordStatus = 'DRAFT' | 'PENDING' | 'APPROVED' | 'REJECTED' | 'VOIDED';

export interface InboundRecord {
  id: string;
  date: string;              // YYYY-MM-DD
  moNumber: string;          // 製令單號
  productName: string;       // 品名
  quantity: number;          // 數量 (正整數)
  wireBatch: string;         // 線材批號
  wireGauge: number;         // 線徑 (mm)
  machineId: string;         // 設備編號
  packer: string;            // 包裝人員
  status: RecordStatus;      // 狀態
  notes?: string;            // 備註
  createdById: string;       // 建立者帳號 ID
  createdByName: string;     // 建立者名稱
  createdAt: string;
  updatedAt: string;
  reviewerId?: string;       // 審核主管
  reviewerName?: string;
  reviewedAt?: string;
  reviewNotes?: string;      // 審核/退回/作廢原因說明
  batchLabelGenerated?: boolean;
}

export interface OutboundRecord {
  id: string;
  date: string;              // 出貨日期 YYYY-MM-DD
  shippingOrderNo: string;   // 客戶出貨單號
  customerName: string;      // 客戶名稱
  productName: string;       // 品名
  quantity: number;          // 出貨數量
  wireBatch: string;         // 指定線材批號
  wireGauge: number;         // 線徑 (mm)
  tallyStation?: string;     // 理貨台/設備編號
  tallyPerson: string;       // 理貨人員
  status: RecordStatus;      // 狀態
  notes?: string;            // 備註
  createdById: string;
  createdByName: string;
  createdAt: string;
  updatedAt: string;
  reviewerId?: string;
  reviewerName?: string;
  reviewedAt?: string;
  reviewNotes?: string;
  stockDeducted?: boolean;   // 是否已扣庫存
}

export interface InventoryItem {
  key: string;
  productName: string;
  wireBatch: string;
  wireGauge: number;
  inboundQty: number;
  outboundQty: number;
  currentStock: number;
  lastUpdated: string;
}

export interface InventoryTransaction {
  id: string;
  type: 'INBOUND' | 'OUTBOUND';
  date: string;
  docNo: string;
  productName: string;
  wireBatch: string;
  wireGauge: number;
  quantity: number;
  targetOrSource: string;
  person: string;
  timestamp: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  userRole: string;
  action: string;
  targetType: 'INBOUND' | 'OUTBOUND' | 'USER' | 'SYSTEM';
  targetId: string;
  details: string;
}

export interface MonthlyReportData {
  month: string;
  totalInboundQty: number;
  totalOutboundQty: number;
  netChange: number;
  inboundRecordCount: number;
  outboundRecordCount: number;
  productBreakdown: {
    productName: string;
    inboundQty: number;
    outboundQty: number;
  }[];
  dailyTrend: {
    date: string;
    inboundQty: number;
    outboundQty: number;
  }[];
}

export interface CustomerImportItem {
  date: string;
  shippingOrderNo: string;
  customerName: string;
  productName: string;
  quantity: number;
  wireBatch: string;
  wireGauge: number;
  tallyStation?: string;
  tallyPerson?: string;
  notes?: string;
}

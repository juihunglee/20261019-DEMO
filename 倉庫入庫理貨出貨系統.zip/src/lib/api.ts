import {
  User,
  InboundRecord,
  OutboundRecord,
  InventoryItem,
  InventoryTransaction,
  AuditLog,
  MonthlyReportData,
  CustomerImportItem,
  RecordStatus
} from '../types/warehouse';

const TOKEN_KEY = 'wms_auth_token';

export const getStoredToken = (): string | null => {
  return localStorage.getItem(TOKEN_KEY);
};

export const setStoredToken = (token: string): void => {
  localStorage.setItem(TOKEN_KEY, token);
};

export const clearStoredToken = (): void => {
  localStorage.removeItem(TOKEN_KEY);
};

async function fetchWithAuth<T>(url: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers = new Headers(options.headers || {});
  headers.set('Content-Type', 'application/json');

  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  const response = await fetch(url, {
    ...options,
    headers
  });

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    const errorMsg = data?.error || `連線伺服器失敗 (${response.status})`;
    throw new Error(errorMsg);
  }

  return data as T;
}

export const api = {
  // Auth
  async login(username: string, password: string): Promise<{ token: string; user: User }> {
    const res = await fetchWithAuth<{ token: string; user: User }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password })
    });
    setStoredToken(res.token);
    return res;
  },

  async getMe(): Promise<{ user: User }> {
    return fetchWithAuth<{ user: User }>('/api/auth/me');
  },

  async logout(): Promise<void> {
    try {
      await fetchWithAuth('/api/auth/logout', { method: 'POST' });
    } finally {
      clearStoredToken();
    }
  },

  // Inbound
  async getInbound(params?: {
    search?: string;
    status?: string;
    startDate?: string;
    endDate?: string;
    myOnly?: boolean;
  }): Promise<{ records: InboundRecord[] }> {
    const query = new URLSearchParams();
    if (params?.search) query.set('search', params.search);
    if (params?.status) query.set('status', params.status);
    if (params?.startDate) query.set('startDate', params.startDate);
    if (params?.endDate) query.set('endDate', params.endDate);
    if (params?.myOnly) query.set('myOnly', 'true');

    return fetchWithAuth<{ records: InboundRecord[] }>(`/api/inbound?${query.toString()}`);
  },

  async createInbound(data: {
    date: string;
    moNumber: string;
    productName: string;
    quantity: number;
    wireBatch: string;
    wireGauge: number;
    machineId: string;
    packer: string;
    notes?: string;
    autoSubmit?: boolean;
  }): Promise<{ record: InboundRecord; message: string }> {
    return fetchWithAuth('/api/inbound', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  async updateInbound(id: string, data: {
    date: string;
    moNumber: string;
    productName: string;
    quantity: number;
    wireBatch: string;
    wireGauge: number;
    machineId: string;
    packer: string;
    notes?: string;
    resubmit?: boolean;
  }): Promise<{ record: InboundRecord; message: string }> {
    return fetchWithAuth(`/api/inbound/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data)
    });
  },

  async inboundAction(id: string, action: 'SUBMIT' | 'APPROVE' | 'REJECT' | 'VOID' | 'RESUBMIT', reviewNotes?: string): Promise<{ record: InboundRecord; message: string }> {
    return fetchWithAuth(`/api/inbound/${id}/action`, {
      method: 'POST',
      body: JSON.stringify({ action, reviewNotes })
    });
  },

  async deleteInbound(id: string): Promise<{ success: boolean; message: string }> {
    return fetchWithAuth(`/api/inbound/${id}`, { method: 'DELETE' });
  },

  // Outbound
  async getOutbound(params?: {
    search?: string;
    status?: string;
    startDate?: string;
    endDate?: string;
    myOnly?: boolean;
  }): Promise<{ records: OutboundRecord[] }> {
    const query = new URLSearchParams();
    if (params?.search) query.set('search', params.search);
    if (params?.status) query.set('status', params.status);
    if (params?.startDate) query.set('startDate', params.startDate);
    if (params?.endDate) query.set('endDate', params.endDate);
    if (params?.myOnly) query.set('myOnly', 'true');

    return fetchWithAuth<{ records: OutboundRecord[] }>(`/api/outbound?${query.toString()}`);
  },

  async createOutbound(data: {
    date: string;
    shippingOrderNo: string;
    customerName: string;
    productName: string;
    quantity: number;
    wireBatch: string;
    wireGauge: number;
    tallyStation?: string;
    tallyPerson: string;
    notes?: string;
    autoSubmit?: boolean;
  }): Promise<{ record: OutboundRecord; message: string }> {
    return fetchWithAuth('/api/outbound', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  async importOutbound(orders: CustomerImportItem[]): Promise<{
    success: boolean;
    count: number;
    importedRecords: OutboundRecord[];
    errors?: string[];
    message: string;
  }> {
    return fetchWithAuth('/api/outbound/import', {
      method: 'POST',
      body: JSON.stringify({ orders })
    });
  },

  async updateOutbound(id: string, data: {
    date: string;
    shippingOrderNo: string;
    customerName: string;
    productName: string;
    quantity: number;
    wireBatch: string;
    wireGauge: number;
    tallyStation?: string;
    tallyPerson: string;
    notes?: string;
    resubmit?: boolean;
  }): Promise<{ record: OutboundRecord; message: string }> {
    return fetchWithAuth(`/api/outbound/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data)
    });
  },

  async outboundAction(id: string, action: 'SUBMIT' | 'APPROVE' | 'REJECT' | 'VOID' | 'RESUBMIT', reviewNotes?: string): Promise<{ record: OutboundRecord; message: string }> {
    return fetchWithAuth(`/api/outbound/${id}/action`, {
      method: 'POST',
      body: JSON.stringify({ action, reviewNotes })
    });
  },

  async deleteOutbound(id: string): Promise<{ success: boolean; message: string }> {
    return fetchWithAuth(`/api/outbound/${id}`, { method: 'DELETE' });
  },

  // Inventory
  async getInventory(): Promise<{ inventory: InventoryItem[] }> {
    return fetchWithAuth<{ inventory: InventoryItem[] }>('/api/inventory');
  },

  async getInventoryTransactions(): Promise<{ transactions: InventoryTransaction[] }> {
    return fetchWithAuth<{ transactions: InventoryTransaction[] }>('/api/inventory/transactions');
  },

  // Reports
  async getMonthlyReport(month?: string): Promise<MonthlyReportData> {
    const q = month ? `?month=${month}` : '';
    return fetchWithAuth<MonthlyReportData>(`/api/reports/monthly${q}`);
  },

  // Audit Logs
  async getAuditLogs(): Promise<{ logs: AuditLog[] }> {
    return fetchWithAuth<{ logs: AuditLog[] }>('/api/audit-logs');
  },

  // Users
  async getUsers(): Promise<{ users: User[] }> {
    return fetchWithAuth<{ users: User[] }>('/api/users');
  },

  async createUser(data: {
    username: string;
    name: string;
    role: 'admin' | 'manager' | 'operator';
    password: string;
    department?: string;
  }): Promise<{ user: User; message: string }> {
    return fetchWithAuth('/api/users', {
      method: 'POST',
      body: JSON.stringify(data)
    });
  },

  async resetDemo(): Promise<{ success: boolean; message: string }> {
    return fetchWithAuth('/api/system/reset-demo', { method: 'POST' });
  }
};

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { User, InboundRecord, OutboundRecord, InventoryItem, InventoryTransaction, UserRole, CustomerImportItem } from './types/warehouse';
import { api, getStoredToken } from './lib/api';
import { Header } from './components/Header';
import { InboundManagement } from './components/InboundManagement';
import { OutboundManagement } from './components/OutboundManagement';
import { InventoryView } from './components/InventoryView';
import { ApprovalWorkflow } from './components/ApprovalWorkflow';
import { ReportExport } from './components/ReportExport';
import { PackagingLabelModal } from './components/PackagingLabelModal';
import { LoginModal } from './components/LoginModal';
import { AuditLogModal } from './components/AuditLogModal';
import { UserManagementModal } from './components/UserManagementModal';
import { SystemSpecModal } from './components/SystemSpecModal';
import { HelpCircle, CheckCircle2, AlertCircle, Info, RefreshCw } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState<'inbound' | 'outbound' | 'inventory' | 'approval' | 'reports'>('inbound');

  // Warehouse data
  const [inboundRecords, setInboundRecords] = useState<InboundRecord[]>([]);
  const [outboundRecords, setOutboundRecords] = useState<OutboundRecord[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [transactions, setTransactions] = useState<InventoryTransaction[]>([]);
  const [isLoadingData, setIsLoadingData] = useState(false);

  // Modals
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [loginLoading, setLoginLoading] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [activeLabel, setActiveLabel] = useState<{ inbound?: InboundRecord; outbound?: OutboundRecord } | null>(null);
  const [isAuditModalOpen, setIsAuditModalOpen] = useState(false);
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [isSpecModalOpen, setIsSpecModalOpen] = useState(false);

  // Toast feedback
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 3500);
  };

  // Refresh all core data
  const refreshAllData = useCallback(async () => {
    try {
      setIsLoadingData(true);
      const [inbRes, outbRes, invRes, txRes] = await Promise.all([
        api.getInbound(),
        api.getOutbound(),
        api.getInventory(),
        api.getInventoryTransactions()
      ]);
      setInboundRecords(inbRes.records);
      setOutboundRecords(outbRes.records);
      setInventory(invRes.inventory);
      setTransactions(txRes.transactions);
    } catch (err: any) {
      console.error('Failed to fetch warehouse data:', err);
      if (err.message && err.message.includes('登入')) {
        setIsLoginModalOpen(true);
      }
    } finally {
      setIsLoadingData(false);
    }
  }, []);

  // Initial authentication check
  useEffect(() => {
    const token = getStoredToken();
    if (!token) {
      // Auto login as default operator for instant trial
      handleLogin('operator', 'operator123');
    } else {
      api.getMe()
        .then(res => {
          setCurrentUser(res.user);
          refreshAllData();
        })
        .catch(() => {
          handleLogin('operator', 'operator123');
        });
    }
  }, []);

  const handleLogin = async (username: string, pwd: string) => {
    try {
      setLoginLoading(true);
      setLoginError('');
      const res = await api.login(username, pwd);
      setCurrentUser(res.user);
      setIsLoginModalOpen(false);
      showToast(`登入成功！歡迎 ${res.user.name} (${res.user.role === 'admin' ? '管理員' : res.user.role === 'manager' ? '主管' : '作業人員'})`);
      await refreshAllData();
    } catch (err: any) {
      setLoginError(err.message || '登入失敗，請確認帳號密碼');
    } finally {
      setLoginLoading(false);
    }
  };

  const handleLogout = async () => {
    await api.logout();
    setCurrentUser(null);
    setIsLoginModalOpen(true);
    showToast('已安全登出系統', 'info');
  };

  // Switch user quickly for multi-role evaluation
  const handleQuickSwitchUser = async (targetRole: UserRole) => {
    const creds: Record<UserRole, { u: string; p: string }> = {
      operator: { u: 'operator', p: 'operator123' },
      manager: { u: 'manager', p: 'manager123' },
      admin: { u: 'admin', p: 'admin123' }
    };
    const c = creds[targetRole];
    await handleLogin(c.u, c.p);
  };

  // Inbound Handlers
  const handleCreateInbound = async (data: any) => {
    const res = await api.createInbound(data);
    showToast(res.message);
    await refreshAllData();
  };

  const handleUpdateInbound = async (id: string, data: any) => {
    const res = await api.updateInbound(id, data);
    showToast(res.message);
    await refreshAllData();
  };

  const handleInboundAction = async (id: string, action: 'SUBMIT' | 'APPROVE' | 'REJECT' | 'VOID' | 'RESUBMIT', note?: string) => {
    const res = await api.inboundAction(id, action, note);
    showToast(res.message);
    await refreshAllData();
  };

  const handleDeleteInbound = async (id: string) => {
    const res = await api.deleteInbound(id);
    showToast(res.message);
    await refreshAllData();
  };

  // Outbound Handlers
  const handleCreateOutbound = async (data: any) => {
    const res = await api.createOutbound(data);
    showToast(res.message);
    await refreshAllData();
  };

  const handleImportOutbound = async (orders: CustomerImportItem[]) => {
    const res = await api.importOutbound(orders);
    showToast(res.message);
    await refreshAllData();
    return res;
  };

  const handleUpdateOutbound = async (id: string, data: any) => {
    const res = await api.updateOutbound(id, data);
    showToast(res.message);
    await refreshAllData();
  };

  const handleOutboundAction = async (id: string, action: 'SUBMIT' | 'APPROVE' | 'REJECT' | 'VOID' | 'RESUBMIT', note?: string) => {
    const res = await api.outboundAction(id, action, note);
    showToast(res.message);
    await refreshAllData();
  };

  const handleDeleteOutbound = async (id: string) => {
    const res = await api.deleteOutbound(id);
    showToast(res.message);
    await refreshAllData();
  };

  // Calculate pending review count for badge
  const pendingReviewCount = 
    inboundRecords.filter(r => r.status === 'PENDING').length +
    outboundRecords.filter(r => r.status === 'PENDING').length;

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans">
      {/* Toast Notification Banner */}
      {toast && (
        <div className="no-print fixed top-4 right-4 z-50 flex items-center gap-2 px-4 py-2.5 rounded-lg shadow-lg text-xs font-semibold animate-in fade-in slide-in-from-top-2 duration-200 transition-all text-white bg-slate-900 border border-slate-700">
          {toast.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
          {toast.type === 'error' && <AlertCircle className="w-4 h-4 text-rose-400" />}
          {toast.type === 'info' && <Info className="w-4 h-4 text-indigo-400" />}
          <span>{toast.message}</span>
        </div>
      )}

      {/* Top Header */}
      <Header
        currentUser={currentUser}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onLogout={handleLogout}
        onOpenAuditLogs={() => setIsAuditModalOpen(true)}
        onOpenUserManagement={() => setIsUserModalOpen(true)}
        onSwitchUserQuick={handleQuickSwitchUser}
        pendingReviewCount={pendingReviewCount}
      />

      {/* Main Workspace Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'inbound' && currentUser && (
          <InboundManagement
            records={inboundRecords}
            currentUser={currentUser}
            onRefresh={refreshAllData}
            onCreate={handleCreateInbound}
            onUpdate={handleUpdateInbound}
            onAction={handleInboundAction}
            onDelete={handleDeleteInbound}
            onOpenLabel={(record) => setActiveLabel({ inbound: record })}
          />
        )}

        {activeTab === 'outbound' && currentUser && (
          <OutboundManagement
            records={outboundRecords}
            inventory={inventory}
            currentUser={currentUser}
            onRefresh={refreshAllData}
            onCreate={handleCreateOutbound}
            onImport={handleImportOutbound}
            onUpdate={handleUpdateOutbound}
            onAction={handleOutboundAction}
            onDelete={handleDeleteOutbound}
            onOpenLabel={(record) => setActiveLabel({ outbound: record })}
          />
        )}

        {activeTab === 'inventory' && (
          <InventoryView
            inventory={inventory}
            transactions={transactions}
            onRefresh={refreshAllData}
          />
        )}

        {activeTab === 'approval' && currentUser && (
          <ApprovalWorkflow
            inboundRecords={inboundRecords}
            outboundRecords={outboundRecords}
            inventory={inventory}
            currentUser={currentUser}
            onRefresh={refreshAllData}
            onInboundAction={handleInboundAction}
            onOutboundAction={handleOutboundAction}
          />
        )}

        {activeTab === 'reports' && (
          <ReportExport
            inboundRecords={inboundRecords}
            outboundRecords={outboundRecords}
          />
        )}
      </main>

      {/* Footer info bar */}
      <footer className="no-print bg-white border-t border-slate-200 py-3 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span>倉庫入庫理貨出貨系統 · 線材製造加工版</span>
            <span aria-hidden="true">·</span>
            <span>後端資料持久化驗證已啟用</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono text-emerald-600 font-medium">Auto Stock Sync Active</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsSpecModalOpen(true)}
              className="text-indigo-600 hover:text-indigo-800 font-semibold flex items-center gap-1 transition-colors"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              查看系統架構與作業手冊
            </button>
            <span aria-hidden="true">·</span>
            <button
              onClick={refreshAllData}
              disabled={isLoadingData}
              className="text-slate-600 hover:text-slate-900 flex items-center gap-1 transition-colors"
              title="重新載入即時資料"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoadingData ? 'animate-spin text-indigo-600' : ''}`} />
              重新整理
            </button>
          </div>
        </div>
      </footer>

      {/* Floating System Specs Quick Button */}
      <div className="no-print fixed bottom-14 right-5 z-30">
        <button
          onClick={() => setIsSpecModalOpen(true)}
          className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full shadow-lg flex items-center gap-2 text-xs font-semibold transition-all hover:scale-105"
        >
          <HelpCircle className="w-4 h-4" />
          <span>系統規格與操作指南</span>
        </button>
      </div>

      {/* Modals */}
      {isLoginModalOpen && (
        <LoginModal
          onLogin={handleLogin}
          isLoading={loginLoading}
          errorMessage={loginError}
        />
      )}

      {activeLabel && (
        <PackagingLabelModal
          inboundRecord={activeLabel.inbound}
          outboundRecord={activeLabel.outbound}
          onClose={() => setActiveLabel(null)}
        />
      )}

      {isAuditModalOpen && (
        <AuditLogModal onClose={() => setIsAuditModalOpen(false)} />
      )}

      {isUserModalOpen && (
        <UserManagementModal
          onClose={() => setIsUserModalOpen(false)}
          onRefreshAll={refreshAllData}
        />
      )}

      {isSpecModalOpen && (
        <SystemSpecModal onClose={() => setIsSpecModalOpen(false)} />
      )}
    </div>
  );
}

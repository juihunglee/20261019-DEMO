import React, { useState } from 'react';
import { InboundRecord, OutboundRecord, User, InventoryItem } from '../types/warehouse';
import { CheckCircle2, XCircle, Ban, AlertCircle, ArrowUpRight, ArrowDownRight, MessageSquare, ShieldCheck, Clock } from 'lucide-react';

interface ApprovalWorkflowProps {
  inboundRecords: InboundRecord[];
  outboundRecords: OutboundRecord[];
  inventory: InventoryItem[];
  currentUser: User;
  onRefresh: () => void;
  onInboundAction: (id: string, action: 'APPROVE' | 'REJECT' | 'VOID', note?: string) => Promise<void>;
  onOutboundAction: (id: string, action: 'APPROVE' | 'REJECT' | 'VOID', note?: string) => Promise<void>;
}

export function ApprovalWorkflow({
  inboundRecords,
  outboundRecords,
  inventory,
  currentUser,
  onRefresh,
  onInboundAction,
  onOutboundAction
}: ApprovalWorkflowProps) {
  const isSupervisorOrAdmin = currentUser.role === 'manager' || currentUser.role === 'admin';

  // Sub tab for pending vs historical
  const [activeSubTab, setActiveSubTab] = useState<'pending' | 'history'>('pending');

  // Action dialog state (for Reject or Void)
  const [actionModal, setActionModal] = useState<{
    isOpen: boolean;
    type: 'INBOUND' | 'OUTBOUND';
    id: string;
    docNo: string;
    action: 'APPROVE' | 'REJECT' | 'VOID';
    note: string;
  }>({
    isOpen: false,
    type: 'INBOUND',
    id: '',
    docNo: '',
    action: 'APPROVE',
    note: ''
  });

  const [isProcessing, setIsProcessing] = useState(false);

  // Pending records
  const pendingInbound = inboundRecords.filter(r => r.status === 'PENDING');
  const pendingOutbound = outboundRecords.filter(r => r.status === 'PENDING');
  const totalPending = pendingInbound.length + pendingOutbound.length;

  // History records (APPROVED, REJECTED, VOIDED)
  const historyInbound = inboundRecords.filter(r => r.status !== 'PENDING' && r.status !== 'DRAFT');
  const historyOutbound = outboundRecords.filter(r => r.status !== 'PENDING' && r.status !== 'DRAFT');

  const openActionDialog = (type: 'INBOUND' | 'OUTBOUND', id: string, docNo: string, action: 'APPROVE' | 'REJECT' | 'VOID') => {
    setActionModal({
      isOpen: true,
      type,
      id,
      docNo,
      action,
      note: action === 'APPROVE' ? '查核無誤，主管審核通過' : ''
    });
  };

  const handleConfirmAction = async () => {
    if ((actionModal.action === 'REJECT' || actionModal.action === 'VOID') && !actionModal.note.trim()) {
      alert(`請輸入${actionModal.action === 'REJECT' ? '退回原因' : '作廢原因'}說明`);
      return;
    }

    try {
      setIsProcessing(true);
      if (actionModal.type === 'INBOUND') {
        await onInboundAction(actionModal.id, actionModal.action, actionModal.note);
      } else {
        await onOutboundAction(actionModal.id, actionModal.action, actionModal.note);
      }
      setActionModal(prev => ({ ...prev, isOpen: false }));
      onRefresh();
    } catch (err: any) {
      alert(err.message || '操作失敗');
    } finally {
      setIsProcessing(false);
    }
  };

  // Helper to find current available stock for outbound
  const getStockInfo = (productName: string, wireBatch: string, wireGauge: number) => {
    const key = `${productName}___${wireBatch}___${wireGauge}`;
    const found = inventory.find(i => i.key === key);
    return found ? found.currentStock : 0;
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">主管審核、退回與作廢簽核</h2>
          <p className="text-xs text-slate-500 mt-1">
            生管與主管專用覆核中心。審核通過後自動執行庫存增減扣帳；退回可附帶改善意見退回現場修改再送審；作廢可取消無效單據並保留紀錄。
          </p>
        </div>

        {!isSupervisorOrAdmin && (
          <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-200 text-amber-800 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>您目前的身份為「一般使用者」，僅供檢視審核狀態。簽核請切換為「主管 (manager)」帳號。</span>
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 text-xs">
        <button
          onClick={() => setActiveSubTab('pending')}
          className={`pb-2.5 font-semibold transition-colors flex items-center gap-2 relative ${
            activeSubTab === 'pending'
              ? 'text-indigo-600 border-b-2 border-indigo-600'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Clock className="w-4 h-4" />
          待審核單據 ({totalPending})
          {totalPending > 0 && (
            <span className="w-2 h-2 rounded-full bg-amber-500" />
          )}
        </button>

        <button
          onClick={() => setActiveSubTab('history')}
          className={`pb-2.5 font-semibold transition-colors flex items-center gap-2 ${
            activeSubTab === 'history'
              ? 'text-indigo-600 border-b-2 border-indigo-600'
              : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          已簽核歷史紀錄 ({historyInbound.length + historyOutbound.length})
        </button>
      </div>

      {/* View 1: Pending Approvals */}
      {activeSubTab === 'pending' && (
        <div className="space-y-6">
          {/* Section 1: Pending Inbound Reports */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ArrowUpRight className="w-4 h-4 text-emerald-600" />
                <h3 className="font-bold text-slate-800 text-sm">
                  包裝日報入庫待審核 ({pendingInbound.length} 筆)
                </h3>
              </div>
              <span className="text-[11px] text-slate-500">核准後將正式計入庫存在庫量</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100/60 border-b border-slate-200 text-slate-600">
                  <tr>
                    <th className="py-2.5 px-4">填報日期</th>
                    <th className="py-2.5 px-4">製令單號</th>
                    <th className="py-2.5 px-4">品名規格</th>
                    <th className="py-2.5 px-4 text-right">入庫數量</th>
                    <th className="py-2.5 px-4">線材批號</th>
                    <th className="py-2.5 px-4">線徑</th>
                    <th className="py-2.5 px-4">包裝人員</th>
                    <th className="py-2.5 px-4 text-right">審核操作</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {pendingInbound.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-slate-400">
                        目前沒有待審核的包裝入庫單據
                      </td>
                    </tr>
                  ) : (
                    pendingInbound.map((rec) => (
                      <tr key={rec.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-3 px-4 font-mono">{rec.date}</td>
                        <td className="py-3 px-4 font-mono font-bold text-slate-900">{rec.moNumber}</td>
                        <td className="py-3 px-4">
                          <span className="font-semibold text-slate-900">{rec.productName}</span>
                          {rec.notes && <p className="text-[11px] text-slate-400 mt-0.5">{rec.notes}</p>}
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-emerald-600 tabular-nums">
                          +{rec.quantity.toLocaleString()}
                        </td>
                        <td className="py-3 px-4 font-mono">{rec.wireBatch}</td>
                        <td className="py-3 px-4 font-mono">{rec.wireGauge.toFixed(3)} mm</td>
                        <td className="py-3 px-4 text-slate-700">{rec.packer}</td>
                        <td className="py-3 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              disabled={!isSupervisorOrAdmin}
                              onClick={() => openActionDialog('INBOUND', rec.id, rec.moNumber, 'APPROVE')}
                              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-medium rounded text-xs transition-colors flex items-center gap-1 disabled:opacity-40"
                              title="核准通過入庫"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              核准
                            </button>
                            <button
                              disabled={!isSupervisorOrAdmin}
                              onClick={() => openActionDialog('INBOUND', rec.id, rec.moNumber, 'REJECT')}
                              className="px-2 py-1 bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 font-medium rounded text-xs transition-colors flex items-center gap-1 disabled:opacity-40"
                              title="退回給現場包裝人員修改"
                            >
                              <XCircle className="w-3.5 h-3.5" />
                              退回
                            </button>
                            <button
                              disabled={!isSupervisorOrAdmin}
                              onClick={() => openActionDialog('INBOUND', rec.id, rec.moNumber, 'VOID')}
                              className="px-2 py-1 text-slate-500 hover:bg-slate-100 rounded text-xs transition-colors disabled:opacity-40"
                              title="作廢該單據"
                            >
                              作廢
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Section 2: Pending Outbound Reports */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ArrowDownRight className="w-4 h-4 text-rose-600" />
                <h3 className="font-bold text-slate-800 text-sm">
                  客戶出貨單理貨待審核扣帳 ({pendingOutbound.length} 筆)
                </h3>
              </div>
              <span className="text-[11px] text-slate-500">核准後將自動從對應規格庫存中即時扣帳</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100/60 border-b border-slate-200 text-slate-600">
                  <tr>
                    <th className="py-2.5 px-4">出貨日期</th>
                    <th className="py-2.5 px-4">客戶出貨單號</th>
                    <th className="py-2.5 px-4">客戶名稱</th>
                    <th className="py-2.5 px-4">品名規格</th>
                    <th className="py-2.5 px-4 text-right">出貨扣帳數</th>
                    <th className="py-2.5 px-4 text-right">目前庫存存量</th>
                    <th className="py-2.5 px-4">批號 / 線徑</th>
                    <th className="py-2.5 px-4">理貨人員</th>
                    <th className="py-2.5 px-4 text-right">審核操作</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {pendingOutbound.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-8 text-center text-slate-400">
                        目前沒有待審核扣帳的客戶出貨單據
                      </td>
                    </tr>
                  ) : (
                    pendingOutbound.map((rec) => {
                      const currentStock = getStockInfo(rec.productName, rec.wireBatch, rec.wireGauge);
                      const isStockSufficient = currentStock >= rec.quantity;

                      return (
                        <tr key={rec.id} className="hover:bg-slate-50/70 transition-colors">
                          <td className="py-3 px-4 font-mono">{rec.date}</td>
                          <td className="py-3 px-4 font-mono font-bold text-slate-900">{rec.shippingOrderNo}</td>
                          <td className="py-3 px-4 font-semibold text-slate-800">{rec.customerName}</td>
                          <td className="py-3 px-4">
                            <span className="font-semibold text-slate-900">{rec.productName}</span>
                            {rec.notes && <p className="text-[11px] text-slate-400 mt-0.5">{rec.notes}</p>}
                          </td>
                          <td className="py-3 px-4 text-right font-mono font-bold text-rose-600 tabular-nums">
                            -{rec.quantity.toLocaleString()}
                          </td>
                          <td className="py-3 px-4 text-right font-mono tabular-nums">
                            <span className={isStockSufficient ? 'font-bold text-slate-800' : 'font-bold text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded'}>
                              {currentStock.toLocaleString()}
                            </span>
                            {!isStockSufficient && (
                              <div className="text-[10px] text-rose-600 mt-0.5 font-sans">庫存不足!</div>
                            )}
                          </td>
                          <td className="py-3 px-4 font-mono">
                            {rec.wireBatch} · {rec.wireGauge.toFixed(3)}mm
                          </td>
                          <td className="py-3 px-4 text-slate-700">{rec.tallyPerson}</td>
                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                disabled={!isSupervisorOrAdmin || !isStockSufficient}
                                onClick={() => openActionDialog('OUTBOUND', rec.id, rec.shippingOrderNo, 'APPROVE')}
                                className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded text-xs transition-colors flex items-center gap-1 disabled:opacity-40"
                                title={isStockSufficient ? '核准並自動執行庫存扣帳' : '庫存不足無法扣帳'}
                              >
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                核准扣帳
                              </button>
                              <button
                                disabled={!isSupervisorOrAdmin}
                                onClick={() => openActionDialog('OUTBOUND', rec.id, rec.shippingOrderNo, 'REJECT')}
                                className="px-2 py-1 bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 font-medium rounded text-xs transition-colors flex items-center gap-1 disabled:opacity-40"
                                title="退回給理貨人員重整"
                              >
                                <XCircle className="w-3.5 h-3.5" />
                                退回
                              </button>
                              <button
                                disabled={!isSupervisorOrAdmin}
                                onClick={() => openActionDialog('OUTBOUND', rec.id, rec.shippingOrderNo, 'VOID')}
                                className="px-2 py-1 text-slate-500 hover:bg-slate-100 rounded text-xs transition-colors disabled:opacity-40"
                                title="作廢"
                              >
                                作廢
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* View 2: History Records */}
      {activeSubTab === 'history' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200">
            <h3 className="font-bold text-slate-800 text-sm">主管審核與處理歷程清單</h3>
            <p className="text-[11px] text-slate-500 mt-0.5">完整保存所有核准、退回原因與作廢紀錄，落實內部稽核責任</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100/60 border-b border-slate-200 text-slate-600">
                <tr>
                  <th className="py-2.5 px-4">簽核時間</th>
                  <th className="py-2.5 px-4">類型</th>
                  <th className="py-2.5 px-4">單號</th>
                  <th className="py-2.5 px-4">品名規格</th>
                  <th className="py-2.5 px-4 text-right">數量</th>
                  <th className="py-2.5 px-4">審核結果</th>
                  <th className="py-2.5 px-4">審核主管</th>
                  <th className="py-2.5 px-4">審核備註 / 退回或作廢原因</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {[...historyInbound.map(r => ({ ...r, _type: 'INBOUND' as const })), ...historyOutbound.map(r => ({ ...r, _type: 'OUTBOUND' as const }))]
                  .sort((a, b) => new Date(b.reviewedAt || b.updatedAt).getTime() - new Date(a.reviewedAt || a.updatedAt).getTime())
                  .map((rec: any) => (
                    <tr key={rec.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4 font-mono text-[11px] text-slate-600">
                        {rec.reviewedAt ? new Date(rec.reviewedAt).toLocaleString('zh-TW', { hour12: false }) : '-'}
                      </td>
                      <td className="py-3 px-4">
                        {rec._type === 'INBOUND' ? (
                          <span className="font-semibold text-emerald-700">入庫日報</span>
                        ) : (
                          <span className="font-semibold text-indigo-700">理貨出貨</span>
                        )}
                      </td>
                      <td className="py-3 px-4 font-mono font-medium text-slate-900">
                        {rec.moNumber || rec.shippingOrderNo}
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-semibold text-slate-900">{rec.productName}</span>
                        <div className="text-[11px] text-slate-400 font-mono">{rec.wireBatch} · {rec.wireGauge.toFixed(3)}mm</div>
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold tabular-nums">
                        {rec._type === 'INBOUND' ? `+${rec.quantity.toLocaleString()}` : `-${rec.quantity.toLocaleString()}`}
                      </td>
                      <td className="py-3 px-4">
                        {rec.status === 'APPROVED' && <span className="text-emerald-700 font-bold">核准通過</span>}
                        {rec.status === 'REJECTED' && <span className="text-rose-700 font-bold">已退回</span>}
                        {rec.status === 'VOIDED' && <span className="text-slate-400 line-through">已作廢</span>}
                      </td>
                      <td className="py-3 px-4 text-slate-700">{rec.reviewerName || '-'}</td>
                      <td className="py-3 px-4 text-slate-600">
                        {rec.reviewNotes || <span className="text-slate-400">無註記</span>}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Action Dialog Modal */}
      {actionModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4">
          <div className="w-full max-w-md bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <h3 className="font-bold text-slate-900 text-sm">
                {actionModal.action === 'APPROVE' && '審核通過簽核確認'}
                {actionModal.action === 'REJECT' && '退回單據與填寫退回原因'}
                {actionModal.action === 'VOID' && '作廢單據確認'}
              </h3>
              <button
                onClick={() => setActionModal(prev => ({ ...prev, isOpen: false }))}
                className="text-slate-400 hover:text-slate-700 text-lg"
              >
                &times;
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div className="text-slate-500">審核標的：</div>
                <div className="font-mono font-bold text-slate-900 mt-0.5 text-sm">
                  {actionModal.docNo} ({actionModal.type === 'INBOUND' ? '入庫包裝單' : '理貨出貨單'})
                </div>
              </div>

              {actionModal.action === 'APPROVE' && actionModal.type === 'OUTBOUND' && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-800">
                  <p className="font-semibold">庫存扣帳警示：</p>
                  <p className="mt-0.5 text-[11px]">
                    核准後系統將自動自現有庫存扣除該筆出貨數量，並產出庫存異動流水帳。
                  </p>
                </div>
              )}

              {actionModal.action === 'REJECT' && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-800">
                  <p className="font-semibold">退回流程說明：</p>
                  <p className="mt-0.5 text-[11px]">
                    退回後該單據將轉為「已退回」狀態。現場作業人員可在介面檢視退回原因，並修正數量、規格或備註後重新送審。
                  </p>
                </div>
              )}

              {actionModal.action === 'VOID' && (
                <div className="p-3 bg-slate-100 border border-slate-300 rounded-lg text-slate-800">
                  <p className="font-semibold">作廢流程說明：</p>
                  <p className="mt-0.5 text-[11px]">
                    作廢後該單據將永久標示為已作廢，不影響在庫庫存，並保留單號與操作歷程供日後稽核。
                  </p>
                </div>
              )}

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {actionModal.action === 'APPROVE' && '簽核審核意見 (選填)'}
                  {actionModal.action === 'REJECT' && '退回原因說明 (必填，以供人員改善)'}
                  {actionModal.action === 'VOID' && '作廢原因說明 (必填)'}
                </label>
                <textarea
                  rows={3}
                  value={actionModal.note}
                  onChange={(e) => setActionModal(prev => ({ ...prev, note: e.target.value }))}
                  placeholder={
                    actionModal.action === 'REJECT'
                      ? '請具體說明退回理由，例如：線徑抽測超差、包裝防潮封口不符、標籤條碼模糊...'
                      : actionModal.action === 'VOID'
                      ? '請輸入作廢原因，例如：客戶訂單取消、重複開單...'
                      : '核對規格數量無誤，准予入庫或出貨'
                  }
                  className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500 text-xs"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setActionModal(prev => ({ ...prev, isOpen: false }))}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-medium"
                >
                  取消
                </button>
                <button
                  type="button"
                  onClick={handleConfirmAction}
                  disabled={isProcessing}
                  className={`px-5 py-2 text-white font-semibold rounded-lg shadow-xs transition-colors ${
                    actionModal.action === 'APPROVE'
                      ? 'bg-emerald-600 hover:bg-emerald-700'
                      : actionModal.action === 'REJECT'
                      ? 'bg-rose-600 hover:bg-rose-700'
                      : 'bg-slate-800 hover:bg-slate-900'
                  }`}
                >
                  {isProcessing ? '處理中...' : '確認執行'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import React from 'react';
import { X, CheckCircle, ShieldCheck, Database, Layers, ArrowRight, HelpCircle } from 'lucide-react';

interface SystemSpecModalProps {
  onClose: () => void;
}

export function SystemSpecModal({ onClose }: SystemSpecModalProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 overflow-y-auto">
      <div className="w-full max-w-4xl max-h-[90vh] bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-indigo-600" />
            <div>
              <h3 className="font-bold text-slate-900 text-sm">系統分析、資料結構與操作作業指南</h3>
              <p className="text-[11px] text-slate-500">倉庫入庫理貨出貨系統規格書與驗收標準</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs text-slate-700 leading-relaxed">
          {/* Section 1 */}
          <section className="space-y-2">
            <h4 className="text-sm font-bold text-slate-900 border-b pb-1 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-indigo-600"></span>
              一、使用目的與痛點解決方案
            </h4>
            <p>
              過去「入庫」、「理貨」、「出貨」各自獨立記帳，導致無法即時反映在庫數量，也無法防止超賣超發。
              本系統透過<strong>統一規格鍵值（品名 + 線材批號 + 線徑）</strong>，在包裝人員填報入庫經主管核准後自動增加入庫總數；理貨人員依客戶出貨單匯入理貨資料，經主管審核出貨後<strong>自動觸發庫存扣帳</strong>，並即時產出符合規範的「標準條碼包裝標籤」與「客戶出貨專用標籤」。
            </p>
          </section>

          {/* Section 2 */}
          <section className="space-y-2">
            <h4 className="text-sm font-bold text-slate-900 border-b pb-1 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-indigo-600"></span>
              二、使用角色與權限架構 (後端 Middleware 強制驗證)
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                <div className="font-bold text-indigo-900 mb-1">1. 一般使用者 (現場人員)</div>
                <ul className="list-disc pl-4 space-y-1 text-[11px]">
                  <li>填報「包裝日報表」即入庫草稿或送審</li>
                  <li>從客戶出貨單匯入或建立理貨單</li>
                  <li>製作與列印包裝合格標籤及出貨標籤</li>
                  <li>僅能修改自己填報之草稿或被退回單據</li>
                </ul>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                <div className="font-bold text-amber-900 mb-1">2. 主管 (生管 / 倉管主管)</div>
                <ul className="list-disc pl-4 space-y-1 text-[11px]">
                  <li>查看全部入庫與理貨出貨紀錄</li>
                  <li>審核簽核：核准通過（觸發庫存扣帳或入庫）</li>
                  <li>退回流程：填寫退回原因退回現場修改再送審</li>
                  <li>作廢流程：填寫作廢原因取消單據</li>
                  <li>查詢月度統計、庫存看板並匯出報表</li>
                </ul>
              </div>

              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg">
                <div className="font-bold text-purple-900 mb-1">3. 系統管理員 (Admin)</div>
                <ul className="list-disc pl-4 space-y-1 text-[11px]">
                  <li>管理使用者帳號、角色分配與部門設定</li>
                  <li>查閱完整系統操作稽核日誌 (Audit Log)</li>
                  <li>維護所有單據資料、必要時刪除或重置示範庫存</li>
                </ul>
              </div>
            </div>
          </section>

          {/* Section 3 */}
          <section className="space-y-2">
            <h4 className="text-sm font-bold text-slate-900 border-b pb-1 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-indigo-600"></span>
              三、資料欄位定義與防呆驗證規則
            </h4>
            <div className="overflow-x-auto border border-slate-200 rounded-lg">
              <table className="w-full text-left text-[11px]">
                <thead className="bg-slate-100 font-semibold text-slate-700">
                  <tr>
                    <th className="p-2">欄位名稱</th>
                    <th className="p-2">系統代碼</th>
                    <th className="p-2">資料型態</th>
                    <th className="p-2">必填</th>
                    <th className="p-2">驗證與防呆邏輯</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  <tr>
                    <td className="p-2 font-medium">日期</td>
                    <td className="p-2 font-mono">date</td>
                    <td className="p-2">Date (字串)</td>
                    <td className="p-2 text-rose-600 font-bold">必填</td>
                    <td className="p-2">正則檢查 YYYY-MM-DD 格式，不可空白</td>
                  </tr>
                  <tr>
                    <td className="p-2 font-medium">製令單號</td>
                    <td className="p-2 font-mono">moNumber</td>
                    <td className="p-2">String</td>
                    <td className="p-2 text-rose-600 font-bold">必填</td>
                    <td className="p-2">非空字串，格式例: MO-20261019-01</td>
                  </tr>
                  <tr>
                    <td className="p-2 font-medium">品名</td>
                    <td className="p-2 font-mono">productName</td>
                    <td className="p-2">String</td>
                    <td className="p-2 text-rose-600 font-bold">必填</td>
                    <td className="p-2">下拉選單或非空字串，線材品名規格</td>
                  </tr>
                  <tr>
                    <td className="p-2 font-medium">數量</td>
                    <td className="p-2 font-mono">quantity</td>
                    <td className="p-2">Integer</td>
                    <td className="p-2 text-rose-600 font-bold">必填</td>
                    <td className="p-2">大於 0 之正整數；出貨審核時自動檢查庫存是否充足</td>
                  </tr>
                  <tr>
                    <td className="p-2 font-medium">線材批號</td>
                    <td className="p-2 font-mono">wireBatch</td>
                    <td className="p-2">String</td>
                    <td className="p-2 text-rose-600 font-bold">必填</td>
                    <td className="p-2">原物料生產批號 (Lot No.)，不可空白</td>
                  </tr>
                  <tr>
                    <td className="p-2 font-medium">線徑</td>
                    <td className="p-2 font-mono">wireGauge</td>
                    <td className="p-2">Float (mm)</td>
                    <td className="p-2 text-rose-600 font-bold">必填</td>
                    <td className="p-2">精確至小數點第三位，必須 &gt; 0 (mm)</td>
                  </tr>
                  <tr>
                    <td className="p-2 font-medium">設備編號</td>
                    <td className="p-2 font-mono">machineId</td>
                    <td className="p-2">String</td>
                    <td className="p-2 text-rose-600 font-bold">必填</td>
                    <td className="p-2">拉線/包裝機台代號 (例: LINE-01)</td>
                  </tr>
                  <tr>
                    <td className="p-2 font-medium">包裝人員</td>
                    <td className="p-2 font-mono">packer</td>
                    <td className="p-2">String</td>
                    <td className="p-2 text-rose-600 font-bold">必填</td>
                    <td className="p-2">作業人員姓名，預設帶入登入者</td>
                  </tr>
                  <tr>
                    <td className="p-2 font-medium">狀態</td>
                    <td className="p-2 font-mono">status</td>
                    <td className="p-2">Enum</td>
                    <td className="p-2 text-rose-600 font-bold">系統控制</td>
                    <td className="p-2">DRAFT | PENDING | APPROVED | REJECTED | VOIDED</td>
                  </tr>
                  <tr>
                    <td className="p-2 font-medium">備註</td>
                    <td className="p-2 font-mono">notes</td>
                    <td className="p-2">String</td>
                    <td className="p-2 text-slate-400">選填</td>
                    <td className="p-2">包裝說明、檢驗數值或客戶特殊指示</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          {/* Section 4 */}
          <section className="space-y-2">
            <h4 className="text-sm font-bold text-slate-900 border-b pb-1 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-indigo-600"></span>
              四、完整作業流程 (含退回修改與作廢機制)
            </h4>
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-2 text-[11px]">
              <div className="flex items-center gap-2 font-bold text-slate-900">
                <span>1. 人員登入</span>
                <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                <span>2. 填寫入庫或匯入客戶理貨單</span>
                <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                <span>3. 產出標籤並送審</span>
                <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                <span>4. 主管審核 (核准/退回/作廢)</span>
              </div>
              <ul className="list-disc pl-4 space-y-1 text-slate-600">
                <li><strong>核准通過 (APPROVE)：</strong> 入庫紀錄正式入帳增加庫存；出貨理貨單檢查庫存後自動扣帳，兩者皆寫入庫存流水帳。</li>
                <li><strong>退回流程 (REJECT)：</strong> 主管發現數量、線徑或防潮包裝不符，必須輸入「退回原因」。原填報人於清單可看見退回標記與主管意見，點選編輯修正後執行「重新送審 (RESUBMIT)」。</li>
                <li><strong>作廢流程 (VOID)：</strong> 因客戶臨時取消或重複建單時，主管輸入「作廢原因」，單據永久標註已作廢，庫存不受影響，並保留單號供內部稽核。</li>
              </ul>
            </div>
          </section>

          {/* Section 5 */}
          <section className="space-y-2">
            <h4 className="text-sm font-bold text-slate-900 border-b pb-1 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-indigo-600"></span>
              五、資料儲存與部署說明
            </h4>
            <p>
              本系統採用 <strong>Node.js Express 全端後端 + 檔案式持久化資料庫 (Atomic Write JSON Engine)</strong>。
              每次新增、修改、刪除、審核，均由伺服器端同步寫入磁碟並寫入稽核日誌。
              即使重新整理瀏覽器、更換電腦或重啟伺服器，所有資料均完整保留。
            </p>
          </section>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 font-medium text-xs transition-colors"
          >
            我已瞭解並返回操作
          </button>
        </div>
      </div>
    </div>
  );
}

import React, { useState, useMemo } from 'react';
import { InventoryItem, InventoryTransaction } from '../types/warehouse';
import { Search, Download, AlertTriangle, CheckCircle, ArrowDownRight, ArrowUpRight, History, Package } from 'lucide-react';

interface InventoryViewProps {
  inventory: InventoryItem[];
  transactions: InventoryTransaction[];
  onRefresh: () => void;
}

export function InventoryView({ inventory, transactions, onRefresh }: InventoryViewProps) {
  const [activeSubTab, setActiveSubTab] = useState<'summary' | 'ledger'>('summary');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredInventory = useMemo(() => {
    if (!searchTerm.trim()) return inventory;
    const q = searchTerm.toLowerCase();
    return inventory.filter(
      item =>
        item.productName.toLowerCase().includes(q) ||
        item.wireBatch.toLowerCase().includes(q) ||
        item.wireGauge.toString().includes(q)
    );
  }, [inventory, searchTerm]);

  const filteredTransactions = useMemo(() => {
    if (!searchTerm.trim()) return transactions;
    const q = searchTerm.toLowerCase();
    return transactions.filter(
      tx =>
        tx.productName.toLowerCase().includes(q) ||
        tx.wireBatch.toLowerCase().includes(q) ||
        tx.docNo.toLowerCase().includes(q) ||
        tx.person.toLowerCase().includes(q) ||
        tx.targetOrSource.toLowerCase().includes(q)
    );
  }, [transactions, searchTerm]);

  // Overall statistics
  const totalStock = useMemo(() => inventory.reduce((sum, i) => sum + i.currentStock, 0), [inventory]);
  const totalInbound = useMemo(() => inventory.reduce((sum, i) => sum + i.inboundQty, 0), [inventory]);
  const totalOutbound = useMemo(() => inventory.reduce((sum, i) => sum + i.outboundQty, 0), [inventory]);
  const lowStockCount = useMemo(() => inventory.filter(i => i.currentStock < 1000).length, [inventory]);

  const exportInventoryCSV = () => {
    const headers = ['品名', '線材批號', '線徑(mm)', '入庫累計', '出貨扣帳累計', '目前在庫庫存', '最後異動時間'];
    const rows = inventory.map(item => [
      item.productName,
      item.wireBatch,
      item.wireGauge.toFixed(3),
      item.inboundQty,
      item.outboundQty,
      item.currentStock,
      item.lastUpdated
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `倉庫即時庫存盤點表_${new Date().toISOString().substring(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner and Overview Cards */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">即時庫存總覽與流水帳</h2>
          <p className="text-xs text-slate-500 mt-1">
            由核准之「包裝入庫日報」累加、並於「客戶理貨出貨」主管簽核後自動扣帳，精確掌握各規格在庫水位。
          </p>
        </div>

        <button
          onClick={exportInventoryCSV}
          className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-1.5 shadow-xs shrink-0"
        >
          <Download className="w-4 h-4 text-slate-500" />
          匯出庫存盤點 CSV
        </button>
      </div>

      {/* KPI Metric Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs font-medium text-slate-500">目前在庫總量</div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="font-mono text-2xl font-bold tracking-tight text-slate-900 tabular-nums">
              {totalStock.toLocaleString()}
            </span>
            <span className="text-xs text-slate-400">PCS / 軸</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs font-medium text-slate-500">累計核准入庫</div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="font-mono text-2xl font-bold tracking-tight text-emerald-600 tabular-nums">
              +{totalInbound.toLocaleString()}
            </span>
            <span className="text-xs text-emerald-600 flex items-center">
              <ArrowUpRight className="w-3.5 h-3.5" /> 入庫
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs font-medium text-slate-500">累計出貨扣帳</div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="font-mono text-2xl font-bold tracking-tight text-rose-600 tabular-nums">
              -{totalOutbound.toLocaleString()}
            </span>
            <span className="text-xs text-rose-600 flex items-center">
              <ArrowDownRight className="w-3.5 h-3.5" /> 扣帳
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs font-medium text-slate-500">低安全存量警示</div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className={`font-mono text-2xl font-bold tracking-tight tabular-nums ${lowStockCount > 0 ? 'text-amber-600' : 'text-slate-900'}`}>
              {lowStockCount} <span className="text-xs font-normal text-slate-500">項規格</span>
            </span>
            {lowStockCount > 0 && (
              <span className="text-xs text-amber-600 flex items-center gap-1 font-semibold">
                <AlertTriangle className="w-3.5 h-3.5" /> 補貨提醒
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Subtab Toggle & Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white p-3 rounded-xl border border-slate-200">
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs">
          <button
            onClick={() => setActiveSubTab('summary')}
            className={`px-3 py-1.5 font-medium rounded-md transition-colors flex items-center gap-1.5 ${
              activeSubTab === 'summary' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            各規格庫存總覽 ({filteredInventory.length})
          </button>
          <button
            onClick={() => setActiveSubTab('ledger')}
            className={`px-3 py-1.5 font-medium rounded-md transition-colors flex items-center gap-1.5 ${
              activeSubTab === 'ledger' ? 'bg-white text-slate-900 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            庫存異動流水帳 ({filteredTransactions.length})
          </button>
        </div>

        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="搜尋品名、線材批號、規格單號..."
            className="w-full pl-9 pr-3 py-1.5 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-indigo-500 bg-slate-50"
          />
        </div>
      </div>

      {/* Tab 1: Inventory Summary Table */}
      {activeSubTab === 'summary' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">品名規格</th>
                  <th className="py-3 px-4">線材批號</th>
                  <th className="py-3 px-4">線徑 (mm)</th>
                  <th className="py-3 px-4 text-right">入庫累計</th>
                  <th className="py-3 px-4 text-right">出貨扣帳累計</th>
                  <th className="py-3 px-4 text-right">現有庫存</th>
                  <th className="py-3 px-4">安全存量狀態</th>
                  <th className="py-3 px-4">最後異動時間</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredInventory.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-10 text-center text-slate-400">
                      尚無核准入庫之在庫資料
                    </td>
                  </tr>
                ) : (
                  filteredInventory.map((item) => {
                    const isLow = item.currentStock < 1000;
                    return (
                      <tr key={item.key} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3 px-4 font-bold text-slate-900">{item.productName}</td>
                        <td className="py-3 px-4 font-mono font-medium text-indigo-700">{item.wireBatch}</td>
                        <td className="py-3 px-4 font-mono text-slate-800">{item.wireGauge.toFixed(3)}</td>
                        <td className="py-3 px-4 text-right font-mono text-emerald-600 font-semibold tabular-nums">
                          +{item.inboundQty.toLocaleString()}
                        </td>
                        <td className="py-3 px-4 text-right font-mono text-rose-600 font-semibold tabular-nums">
                          -{item.outboundQty.toLocaleString()}
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-bold text-base tabular-nums text-slate-900">
                          {item.currentStock.toLocaleString()}
                        </td>
                        <td className="py-3 px-4">
                          {isLow ? (
                            <span className="text-amber-700 font-semibold flex items-center gap-1">
                              <AlertTriangle className="w-3.5 h-3.5" /> 低於安全存量
                            </span>
                          ) : (
                            <span className="text-emerald-700 font-medium flex items-center gap-1">
                              <CheckCircle className="w-3.5 h-3.5" /> 正常儲量
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4 font-mono text-[11px] text-slate-500">
                          {new Date(item.lastUpdated).toLocaleString('zh-TW', { hour12: false })}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: Transaction Ledger Timeline */}
      {activeSubTab === 'ledger' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider">
                <tr>
                  <th className="py-3 px-4">異動時間</th>
                  <th className="py-3 px-4">類型</th>
                  <th className="py-3 px-4">單號 (製令/出貨)</th>
                  <th className="py-3 px-4">品名規格</th>
                  <th className="py-3 px-4">批號 / 線徑</th>
                  <th className="py-3 px-4 text-right">異動數量</th>
                  <th className="py-3 px-4">對象 (機台/客戶)</th>
                  <th className="py-3 px-4">經手人員</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredTransactions.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="py-10 text-center text-slate-400">
                      尚無核准生效的庫存進出異動紀錄
                    </td>
                  </tr>
                ) : (
                  filteredTransactions.map((tx) => (
                    <tr key={tx.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-4 font-mono text-[11px] text-slate-600">
                        {new Date(tx.timestamp).toLocaleString('zh-TW', { hour12: false })}
                      </td>
                      <td className="py-3 px-4">
                        {tx.type === 'INBOUND' ? (
                          <span className="text-emerald-700 font-bold flex items-center gap-1">
                            <ArrowUpRight className="w-3.5 h-3.5" /> 入庫增加
                          </span>
                        ) : (
                          <span className="text-rose-700 font-bold flex items-center gap-1">
                            <ArrowDownRight className="w-3.5 h-3.5" /> 出貨扣帳
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 font-mono font-medium text-slate-900">{tx.docNo}</td>
                      <td className="py-3 px-4 font-semibold text-slate-900">{tx.productName}</td>
                      <td className="py-3 px-4 font-mono text-slate-700">
                        {tx.wireBatch} · {tx.wireGauge.toFixed(3)}mm
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold tabular-nums">
                        <span className={tx.quantity > 0 ? 'text-emerald-600' : 'text-rose-600'}>
                          {tx.quantity > 0 ? `+${tx.quantity.toLocaleString()}` : tx.quantity.toLocaleString()}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-700">{tx.targetOrSource}</td>
                      <td className="py-3 px-4 text-slate-600">{tx.person}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

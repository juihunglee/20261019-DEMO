import React, { useState, useMemo } from 'react';
import { OutboundRecord, User, RecordStatus, CustomerImportItem, InventoryItem } from '../types/warehouse';
import {
  Plus, Search, Filter, Printer, Edit2, Trash2, Send,
  Upload, CheckCircle2, Clock, AlertCircle, FileSpreadsheet, RotateCcw, ChevronLeft, ChevronRight
} from 'lucide-react';

interface OutboundManagementProps {
  records: OutboundRecord[];
  inventory: InventoryItem[];
  currentUser: User;
  onRefresh: () => void;
  onCreate: (data: any) => Promise<void>;
  onImport: (orders: CustomerImportItem[]) => Promise<any>;
  onUpdate: (id: string, data: any) => Promise<void>;
  onAction: (id: string, action: 'SUBMIT' | 'APPROVE' | 'REJECT' | 'VOID' | 'RESUBMIT', note?: string) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
  onOpenLabel: (record: OutboundRecord) => void;
}

export function OutboundManagement({
  records,
  inventory,
  currentUser,
  onRefresh,
  onCreate,
  onImport,
  onUpdate,
  onAction,
  onDelete,
  onOpenLabel
}: OutboundManagementProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [myOnly, setMyOnly] = useState(false);

  // Form modal
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<OutboundRecord | null>(null);
  const [formData, setFormData] = useState({
    date: new Date().toISOString().substring(0, 10),
    shippingOrderNo: '',
    customerName: '',
    productName: '無氧銅精拉線',
    quantity: 1000,
    wireBatch: '',
    wireGauge: 0.85,
    tallyStation: '理貨區-A',
    tallyPerson: currentUser.name,
    notes: '',
    autoSubmit: true
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Import modal
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [importText, setImportText] = useState('');
  const [importPreviewList, setImportPreviewList] = useState<CustomerImportItem[]>([]);
  const [importError, setImportError] = useState('');

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;

  // Filtered
  const filteredRecords = useMemo(() => {
    return records.filter(r => {
      if (myOnly && r.createdById !== currentUser.id) return false;
      if (statusFilter !== 'ALL' && r.status !== statusFilter) return false;
      if (startDate && r.date < startDate) return false;
      if (endDate && r.date > endDate) return false;
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const matchSo = r.shippingOrderNo.toLowerCase().includes(q);
        const matchCust = r.customerName.toLowerCase().includes(q);
        const matchProd = r.productName.toLowerCase().includes(q);
        const matchBatch = r.wireBatch.toLowerCase().includes(q);
        const matchPerson = r.tallyPerson.toLowerCase().includes(q);
        if (!matchSo && !matchCust && !matchProd && !matchBatch && !matchPerson) return false;
      }
      return true;
    });
  }, [records, myOnly, currentUser.id, statusFilter, startDate, endDate, searchTerm]);

  const totalPages = Math.max(1, Math.ceil(filteredRecords.length / pageSize));
  const paginatedRecords = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredRecords.slice(start, start + pageSize);
  }, [filteredRecords, currentPage]);

  const handleOpenCreate = () => {
    const today = new Date().toISOString().substring(0, 10);
    const randomSuffix = Math.floor(100 + Math.random() * 900);
    setEditingRecord(null);
    setFormData({
      date: today,
      shippingOrderNo: `SO-${today.replace(/-/g, '')}-C${randomSuffix}`,
      customerName: '台灣電工精密股份有限公司',
      productName: '無氧銅精拉線',
      quantity: 1500,
      wireBatch: 'LOT-CU-2610A',
      wireGauge: 0.85,
      tallyStation: '理貨台-01',
      tallyPerson: currentUser.name,
      notes: '',
      autoSubmit: true
    });
    setFormErrors({});
    setIsFormOpen(true);
  };

  const handleOpenEdit = (rec: OutboundRecord) => {
    setEditingRecord(rec);
    setFormData({
      date: rec.date,
      shippingOrderNo: rec.shippingOrderNo,
      customerName: rec.customerName,
      productName: rec.productName,
      quantity: rec.quantity,
      wireBatch: rec.wireBatch,
      wireGauge: rec.wireGauge,
      tallyStation: rec.tallyStation || '理貨區-A',
      tallyPerson: rec.tallyPerson,
      notes: rec.notes || '',
      autoSubmit: rec.status === 'REJECTED'
    });
    setFormErrors({});
    setIsFormOpen(true);
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};
    if (!formData.date) errors.date = '請選擇出貨日期';
    if (!formData.shippingOrderNo.trim()) errors.shippingOrderNo = '請輸入出貨單號';
    if (!formData.customerName.trim()) errors.customerName = '請輸入客戶名稱';
    if (!formData.productName.trim()) errors.productName = '請輸入品名';
    if (!formData.quantity || formData.quantity <= 0) errors.quantity = '出貨數量必須大於 0';
    if (!formData.wireBatch.trim()) errors.wireBatch = '請輸入指定線材批號';
    if (!formData.wireGauge || formData.wireGauge <= 0) errors.wireGauge = '請輸入有效線徑';
    if (!formData.tallyPerson.trim()) errors.tallyPerson = '請輸入理貨人員';
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    try {
      setIsSubmitting(true);
      if (editingRecord) {
        await onUpdate(editingRecord.id, {
          ...formData,
          resubmit: formData.autoSubmit
        });
      } else {
        await onCreate(formData);
      }
      setIsFormOpen(false);
      onRefresh();
    } catch (err: any) {
      alert(err.message || '儲存失敗');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Demo sample customer orders for instant 1-click import
  const loadDemoCustomerOrders = () => {
    const today = new Date().toISOString().substring(0, 10);
    const demoItems: CustomerImportItem[] = [
      {
        date: today,
        shippingOrderNo: `SO-${today.replace(/-/g, '')}-P91`,
        customerName: '聯茂科技 (ITEQ)',
        productName: '無氧銅精拉線',
        quantity: 1200,
        wireBatch: 'LOT-CU-2610A',
        wireGauge: 0.85,
        tallyStation: '理貨台-02',
        tallyPerson: currentUser.name,
        notes: '客戶系統單號 PO-2026-8802，指定真空包裝'
      },
      {
        date: today,
        shippingOrderNo: `SO-${today.replace(/-/g, '')}-P92`,
        customerName: '欣興電子 (Unimicron)',
        productName: '鍍錫銅絞線',
        quantity: 800,
        wireBatch: 'LOT-SN-2610B',
        wireGauge: 1.20,
        tallyStation: '理貨台-01',
        tallyPerson: currentUser.name,
        notes: '附 SGS 檢驗無鹵認證報告'
      },
      {
        date: today,
        shippingOrderNo: `SO-${today.replace(/-/g, '')}-P93`,
        customerName: '台達電子工業 (Delta)',
        productName: '無氧銅精拉線',
        quantity: 1500,
        wireBatch: 'LOT-CU-2610A',
        wireGauge: 0.85,
        tallyStation: '理貨台-03',
        tallyPerson: currentUser.name,
        notes: '急件車趟出貨，指定棧板封膜'
      }
    ];

    setImportPreviewList(demoItems);
    setImportText(
      demoItems
        .map(
          item =>
            `${item.date},${item.shippingOrderNo},${item.customerName},${item.productName},${item.quantity},${item.wireBatch},${item.wireGauge},${item.tallyStation},${item.notes}`
        )
        .join('\n')
    );
    setImportError('');
  };

  const handleParseCustomCSV = (text: string) => {
    setImportText(text);
    if (!text.trim()) {
      setImportPreviewList([]);
      setImportError('');
      return;
    }

    try {
      const lines = text.trim().split('\n');
      const items: CustomerImportItem[] = [];

      lines.forEach((line, idx) => {
        const row = line.split(',').map(s => s.trim());
        // Expected format: date, shippingOrderNo, customerName, productName, quantity, wireBatch, wireGauge, [tallyStation], [notes]
        if (row.length >= 7) {
          const qty = parseInt(row[4], 10);
          const gauge = parseFloat(row[6]);
          if (!isNaN(qty) && !isNaN(gauge)) {
            items.push({
              date: row[0],
              shippingOrderNo: row[1],
              customerName: row[2],
              productName: row[3],
              quantity: qty,
              wireBatch: row[5],
              wireGauge: gauge,
              tallyStation: row[7] || '理貨區-A',
              tallyPerson: currentUser.name,
              notes: row[8] || '客戶系統單據匯入'
            });
          }
        }
      });

      if (items.length === 0) {
        setImportError('無法辨識 CSV 格式，請確認包含：日期,出貨單號,客戶名稱,品名,數量,線材批號,線徑');
      } else {
        setImportError('');
      }
      setImportPreviewList(items);
    } catch (e: any) {
      setImportError(`解析錯誤: ${e.message}`);
    }
  };

  const handleExecuteImport = async () => {
    if (importPreviewList.length === 0) return;
    try {
      setIsSubmitting(true);
      const res = await onImport(importPreviewList);
      setIsImportModalOpen(false);
      setImportPreviewList([]);
      setImportText('');
      onRefresh();
      alert(res.message || '匯入成功！已送交主管審核出貨扣帳。');
    } catch (err: any) {
      alert(err.message || '匯入失敗');
    } finally {
      setIsSubmitting(false);
    }
  };

  const statusBadge = (status: RecordStatus) => {
    switch (status) {
      case 'DRAFT':
        return <span className="text-slate-600 font-medium">草稿</span>;
      case 'PENDING':
        return <span className="text-amber-700 font-semibold flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> 待主管審核扣帳</span>;
      case 'APPROVED':
        return <span className="text-emerald-700 font-bold flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5" /> 已核准出貨 (已扣庫存)</span>;
      case 'REJECTED':
        return <span className="text-rose-700 font-semibold flex items-center gap-1"><AlertCircle className="w-3.5 h-3.5" /> 已退回</span>;
      case 'VOIDED':
        return <span className="text-slate-400 font-medium line-through">已作廢</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top action row */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">理貨作業與出貨扣帳</h2>
          <p className="text-xs text-slate-500 mt-1">
            依據客戶出貨系統單據完成理貨與專用標籤製作，審核通過後自動執行庫存扣帳，徹底解決重複記帳與庫存落差。
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => {
              setIsImportModalOpen(true);
              loadDemoCustomerOrders();
            }}
            className="px-3.5 py-2 text-xs font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 rounded-lg hover:bg-indigo-100 transition-colors flex items-center gap-1.5"
          >
            <Upload className="w-4 h-4" />
            匯入客戶出貨單
          </button>
          <button
            onClick={handleOpenCreate}
            className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Plus className="w-4 h-4" />
            手動新增理貨單
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[280px]">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => { setSearchTerm(e.target.value); setCurrentPage(1); }}
              placeholder="搜尋出貨單號、客戶名稱、品名、線材批號、理貨人員..."
              className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500 bg-slate-50 text-xs"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value); setCurrentPage(1); }}
            className="px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-slate-700 focus:outline-none"
          >
            <option value="ALL">全部狀態</option>
            <option value="DRAFT">草稿</option>
            <option value="PENDING">待審核扣帳</option>
            <option value="APPROVED">已出貨扣帳</option>
            <option value="REJECTED">已退回</option>
            <option value="VOIDED">已作廢</option>
          </select>

          <input
            type="date"
            value={startDate}
            onChange={(e) => { setStartDate(e.target.value); setCurrentPage(1); }}
            title="起始日期"
            className="px-2.5 py-1.5 border border-slate-200 rounded-lg bg-slate-50 text-slate-700 text-xs"
          />
          <span className="text-slate-400">~</span>
          <input
            type="date"
            value={endDate}
            onChange={(e) => { setEndDate(e.target.value); setCurrentPage(1); }}
            title="結束日期"
            className="px-2.5 py-1.5 border border-slate-200 rounded-lg bg-slate-50 text-slate-700 text-xs"
          />
        </div>

        <div className="flex items-center gap-3">
          <label className="flex items-center gap-1.5 cursor-pointer text-slate-600">
            <input
              type="checkbox"
              checked={myOnly}
              onChange={(e) => { setMyOnly(e.target.checked); setCurrentPage(1); }}
              className="rounded text-indigo-600 focus:ring-indigo-500 w-3.5 h-3.5"
            />
            <span>僅顯示我建立的</span>
          </label>

          {(searchTerm || statusFilter !== 'ALL' || startDate || endDate || myOnly) && (
            <button
              onClick={() => {
                setSearchTerm('');
                setStatusFilter('ALL');
                setStartDate('');
                setEndDate('');
                setMyOnly(false);
                setCurrentPage(1);
              }}
              className="text-indigo-600 hover:text-indigo-800 underline text-xs ml-1"
            >
              重設篩選
            </button>
          )}
        </div>
      </div>

      {/* Outbound Records Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">出貨日期</th>
                <th className="py-3 px-4">客戶出貨單號</th>
                <th className="py-3 px-4">客戶名稱</th>
                <th className="py-3 px-4">品名規格</th>
                <th className="py-3 px-4 text-right">出貨數量</th>
                <th className="py-3 px-4">線材批號</th>
                <th className="py-3 px-4">線徑 (mm)</th>
                <th className="py-3 px-4">理貨員</th>
                <th className="py-3 px-4">狀態</th>
                <th className="py-3 px-4 text-right">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginatedRecords.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-12 text-center text-slate-400">
                    <p className="text-sm">尚無符合條件的理貨出貨紀錄</p>
                    <p className="text-xs mt-1">請點選上方「匯入客戶出貨單」或「手動新增理貨單」</p>
                  </td>
                </tr>
              ) : (
                paginatedRecords.map((rec) => {
                  const canEdit =
                    currentUser.role === 'admin' ||
                    (currentUser.id === rec.createdById && (rec.status === 'DRAFT' || rec.status === 'REJECTED'));
                  const canDelete =
                    currentUser.role === 'admin' ||
                    (currentUser.id === rec.createdById && rec.status === 'DRAFT');

                  return (
                    <tr key={rec.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-4 font-mono text-slate-700">{rec.date}</td>
                      <td className="py-3 px-4 font-mono font-medium text-slate-900">
                        {rec.shippingOrderNo}
                      </td>
                      <td className="py-3 px-4 font-semibold text-slate-800">{rec.customerName}</td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900">{rec.productName}</div>
                        {rec.notes && <div className="text-[11px] text-slate-400 truncate max-w-xs">{rec.notes}</div>}
                        {rec.status === 'REJECTED' && rec.reviewNotes && (
                          <div className="text-[11px] text-rose-600 font-medium mt-0.5">
                            退回原因: {rec.reviewNotes}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold tabular-nums text-rose-600">
                        -{rec.quantity.toLocaleString()}
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-700">{rec.wireBatch}</td>
                      <td className="py-3 px-4 font-mono text-slate-800">{rec.wireGauge.toFixed(3)}</td>
                      <td className="py-3 px-4 text-slate-700">{rec.tallyPerson}</td>
                      <td className="py-3 px-4">{statusBadge(rec.status)}</td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Print Label */}
                          <button
                            onClick={() => onOpenLabel(rec)}
                            title="預覽與列印出貨標籤"
                            className="p-1.5 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded transition-colors"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>

                          {/* Submit from draft */}
                          {rec.status === 'DRAFT' && (
                            <button
                              onClick={() => onAction(rec.id, 'SUBMIT')}
                              title="送交主管審核出貨扣帳"
                              className="p-1.5 text-amber-600 hover:text-amber-800 hover:bg-amber-50 rounded transition-colors"
                            >
                              <Send className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* Resubmit from rejected */}
                          {rec.status === 'REJECTED' && canEdit && (
                            <button
                              onClick={() => handleOpenEdit(rec)}
                              title="修改並重新送審"
                              className="p-1.5 text-rose-600 hover:text-rose-800 hover:bg-rose-50 rounded transition-colors"
                            >
                              <RotateCcw className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* Edit */}
                          {canEdit && (
                            <button
                              onClick={() => handleOpenEdit(rec)}
                              title="編輯"
                              className="p-1.5 text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* Delete */}
                          {canDelete && (
                            <button
                              onClick={async () => {
                                if (window.confirm(`確定要刪除出貨單【${rec.shippingOrderNo}】的理貨紀錄嗎？`)) {
                                  await onDelete(rec.id);
                                  onRefresh();
                                }
                              }}
                              title="刪除"
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        <div className="px-4 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <div>
            總共 <span className="font-semibold text-slate-700">{filteredRecords.length}</span> 筆紀錄
            {filteredRecords.length > 0 && ` (第 ${currentPage} / ${totalPages} 頁)`}
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage <= 1}
              className="p-1.5 rounded border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="px-2 font-mono">{currentPage}</span>
            <button
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage >= totalPages}
              className="p-1.5 rounded border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Modal: Customer Shipping Orders Batch Import */}
      {isImportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 overflow-y-auto">
          <div className="w-full max-w-3xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
              <div className="flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5 text-indigo-600" />
                <h3 className="font-semibold text-slate-900 text-sm">客戶出貨單系統明細批次匯入</h3>
              </div>
              <button
                onClick={() => setIsImportModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 text-lg leading-none"
              >
                &times;
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div className="flex justify-between items-center">
                <p className="text-slate-600">
                  可直接貼上客戶出貨單格式 CSV 文字，或點擊右側按鈕快速載入客戶訂單範本：
                </p>
                <button
                  type="button"
                  onClick={loadDemoCustomerOrders}
                  className="px-3 py-1 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 border border-indigo-200 rounded font-medium text-[11px]"
                >
                  載入客戶訂單示範資料
                </button>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  出貨單 CSV 格式 (每行一筆：日期, 出貨單號, 客戶名稱, 品名, 數量, 線材批號, 線徑, [理貨台], [備註])
                </label>
                <textarea
                  rows={4}
                  value={importText}
                  onChange={(e) => handleParseCustomCSV(e.target.value)}
                  placeholder="2026-10-19,SO-20261019-T01,台灣電工,無氧銅精拉線,1500,LOT-CU-2610A,0.85,理貨區-A,急件出貨"
                  className="w-full p-3 font-mono text-xs border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500 bg-slate-50"
                />
                {importError && <p className="text-rose-600 mt-1">{importError}</p>}
              </div>

              {/* Preview Table */}
              <div>
                <h4 className="font-semibold text-slate-800 mb-2 flex items-center justify-between">
                  <span>匯入明細預覽 ({importPreviewList.length} 筆)</span>
                  <span className="text-slate-400 font-normal">匯入後自動生成理貨紀錄並送交主管審核出貨扣帳</span>
                </h4>

                <div className="max-h-56 overflow-y-auto border border-slate-200 rounded-lg">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-100 text-slate-700 font-semibold sticky top-0">
                      <tr>
                        <th className="py-2 px-3">單號</th>
                        <th className="py-2 px-3">客戶</th>
                        <th className="py-2 px-3">品名</th>
                        <th className="py-2 px-3 text-right">出貨數量</th>
                        <th className="py-2 px-3">批號</th>
                        <th className="py-2 px-3">線徑</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {importPreviewList.map((item, idx) => (
                        <tr key={idx} className="hover:bg-slate-50">
                          <td className="py-2 px-3 font-mono">{item.shippingOrderNo}</td>
                          <td className="py-2 px-3 font-medium text-slate-900">{item.customerName}</td>
                          <td className="py-2 px-3">{item.productName}</td>
                          <td className="py-2 px-3 text-right font-mono font-bold text-rose-600 tabular-nums">
                            {item.quantity.toLocaleString()}
                          </td>
                          <td className="py-2 px-3 font-mono">{item.wireBatch}</td>
                          <td className="py-2 px-3 font-mono">{item.wireGauge.toFixed(3)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsImportModalOpen(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-medium"
                >
                  取消
                </button>
                <button
                  type="button"
                  onClick={handleExecuteImport}
                  disabled={importPreviewList.length === 0 || isSubmitting}
                  className="px-5 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 font-semibold shadow-xs disabled:opacity-50"
                >
                  {isSubmitting ? '匯入處理中...' : `確認匯入 ${importPreviewList.length} 筆客戶出貨單`}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Manual Create / Edit Form */}
      {isFormOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 overflow-y-auto">
          <div className="w-full max-w-lg bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
              <h3 className="font-semibold text-slate-900 text-sm">
                {editingRecord ? `修改理貨單 (${editingRecord.shippingOrderNo})` : '新增理貨出貨單'}
              </h3>
              <button
                onClick={() => setIsFormOpen(false)}
                className="text-slate-400 hover:text-slate-700 text-lg leading-none"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="p-6 space-y-4 text-xs">
              {editingRecord?.status === 'REJECTED' && editingRecord.reviewNotes && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-800">
                  <div className="font-bold flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" /> 主管退回原因說明:
                  </div>
                  <p className="mt-1 text-[11px]">{editingRecord.reviewNotes}</p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    出貨日期 <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500"
                  />
                  {formErrors.date && <p className="text-rose-500 text-[10px] mt-0.5">{formErrors.date}</p>}
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    客戶出貨單號 <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.shippingOrderNo}
                    onChange={(e) => setFormData({ ...formData, shippingOrderNo: e.target.value })}
                    placeholder="例: SO-20261019-C01"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500 font-mono"
                  />
                  {formErrors.shippingOrderNo && <p className="text-rose-500 text-[10px] mt-0.5">{formErrors.shippingOrderNo}</p>}
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  客戶名稱 <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={formData.customerName}
                  onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                  placeholder="例: 台灣電工精密股份有限公司"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500"
                />
                {formErrors.customerName && <p className="text-rose-500 text-[10px] mt-0.5">{formErrors.customerName}</p>}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    品名 <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={formData.productName}
                    onChange={(e) => setFormData({ ...formData, productName: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500"
                  >
                    <option value="無氧銅精拉線">無氧銅精拉線</option>
                    <option value="鍍錫銅絞線">鍍錫銅絞線</option>
                    <option value="漆包絕緣銅線">漆包絕緣銅線</option>
                    <option value="磷青銅圓線">磷青銅圓線</option>
                    <option value="黃銅精密細線">黃銅精密細線</option>
                  </select>
                  {formErrors.productName && <p className="text-rose-500 text-[10px] mt-0.5">{formErrors.productName}</p>}
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    出貨扣帳數量 <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="1"
                    value={formData.quantity}
                    onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500 font-mono font-bold text-rose-600"
                  />
                  {formErrors.quantity && <p className="text-rose-500 text-[10px] mt-0.5">{formErrors.quantity}</p>}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    指定線材批號 <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.wireBatch}
                    onChange={(e) => setFormData({ ...formData, wireBatch: e.target.value })}
                    placeholder="例: LOT-CU-2610A"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500 font-mono"
                  />
                  {formErrors.wireBatch && <p className="text-rose-500 text-[10px] mt-0.5">{formErrors.wireBatch}</p>}
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    線徑 (mm) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    step="0.001"
                    min="0.01"
                    value={formData.wireGauge}
                    onChange={(e) => setFormData({ ...formData, wireGauge: parseFloat(e.target.value) || 0 })}
                    placeholder="例: 0.850"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500 font-mono"
                  />
                  {formErrors.wireGauge && <p className="text-rose-500 text-[10px] mt-0.5">{formErrors.wireGauge}</p>}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">理貨台/設備</label>
                  <input
                    type="text"
                    value={formData.tallyStation}
                    onChange={(e) => setFormData({ ...formData, tallyStation: e.target.value })}
                    placeholder="例: 理貨台-01"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    理貨人員 <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.tallyPerson}
                    onChange={(e) => setFormData({ ...formData, tallyPerson: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500"
                  />
                  {formErrors.tallyPerson && <p className="text-rose-500 text-[10px] mt-0.5">{formErrors.tallyPerson}</p>}
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">理貨備註</label>
                <textarea
                  rows={2}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="可註明裝箱規格、客戶驗貨特別要求或指定貨運..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div className="pt-2 border-t border-slate-200">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.autoSubmit}
                    onChange={(e) => setFormData({ ...formData, autoSubmit: e.target.checked })}
                    className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                  />
                  <span className="font-semibold text-slate-800">
                    {editingRecord?.status === 'REJECTED' ? '儲存並立即重新送審' : '儲存後直接送交主管審核扣帳'}
                  </span>
                </label>
                <p className="text-[11px] text-slate-500 mt-0.5 ml-6">
                  送審後由主管進行出貨簽核，核准時系統將自動扣除對應庫存。
                </p>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-medium"
                >
                  取消
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 font-semibold shadow-xs disabled:opacity-50"
                >
                  {isSubmitting ? '處理中...' : '確認儲存'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

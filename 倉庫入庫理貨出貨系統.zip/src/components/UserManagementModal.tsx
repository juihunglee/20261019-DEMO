import React, { useState, useEffect } from 'react';
import { User, UserRole } from '../types/warehouse';
import { api } from '../lib/api';
import { Shield, UserPlus, X, RefreshCw, CheckCircle, AlertCircle } from 'lucide-react';

interface UserManagementModalProps {
  onClose: () => void;
  onRefreshAll: () => void;
}

export function UserManagementModal({ onClose, onRefreshAll }: UserManagementModalProps) {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);

  const [formData, setFormData] = useState({
    username: '',
    name: '',
    role: 'operator' as UserRole,
    department: '包裝理貨課',
    password: ''
  });
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const res = await api.getUsers();
      setUsers(res.users);
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!formData.username.trim() || !formData.name.trim() || !formData.password.trim()) {
      setErrorMsg('帳號、姓名與密碼皆為必填');
      return;
    }

    try {
      const res = await api.createUser(formData);
      setSuccessMsg(`帳號【${res.user.username}】建立成功`);
      setFormData({
        username: '',
        name: '',
        role: 'operator',
        department: '包裝理貨課',
        password: ''
      });
      setIsAdding(false);
      fetchUsers();
    } catch (err: any) {
      setErrorMsg(err.message || '建立使用者失敗');
    }
  };

  const handleResetDemoData = async () => {
    if (window.confirm('確定要將系統重置為初始示範資料嗎？這將重新載入初始入庫、出貨與預設使用者。')) {
      try {
        await api.resetDemo();
        alert('系統已重置為初始示範狀態！');
        fetchUsers();
        onRefreshAll();
        onClose();
      } catch (err: any) {
        alert(err.message || '重置失敗');
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 overflow-y-auto">
      <div className="w-full max-w-2xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-indigo-600" />
            <div>
              <h3 className="font-bold text-slate-900 text-sm">系統帳號與權限管理 (管理員專用)</h3>
              <p className="text-[11px] text-slate-500">管理員工登入帳號、所屬部門與角色權限劃分</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4 text-xs">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}
          {successMsg && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-lg flex items-center gap-2">
              <CheckCircle className="w-4 h-4 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* User List */}
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex justify-between items-center">
              <span className="font-bold text-slate-700">系統現有帳號清單</span>
              <button
                onClick={() => setIsAdding(!isAdding)}
                className="px-2.5 py-1 bg-indigo-600 text-white rounded font-medium hover:bg-indigo-700 flex items-center gap-1"
              >
                <UserPlus className="w-3.5 h-3.5" />
                {isAdding ? '收起表單' : '新增帳號'}
              </button>
            </div>

            <table className="w-full text-left">
              <thead className="bg-slate-100/60 border-b border-slate-200 text-slate-600">
                <tr>
                  <th className="py-2 px-3">帳號</th>
                  <th className="py-2 px-3">姓名</th>
                  <th className="py-2 px-3">角色權限</th>
                  <th className="py-2 px-3">所屬部門</th>
                  <th className="py-2 px-3">狀態</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users.map(u => (
                  <tr key={u.id} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-mono font-medium text-slate-900">{u.username}</td>
                    <td className="py-2 px-3 font-semibold text-slate-800">{u.name}</td>
                    <td className="py-2 px-3">
                      {u.role === 'admin' && <span className="text-purple-700 font-bold">系統管理員</span>}
                      {u.role === 'manager' && <span className="text-amber-700 font-bold">生管主管</span>}
                      {u.role === 'operator' && <span className="text-slate-700 font-medium">一般作業員</span>}
                    </td>
                    <td className="py-2 px-3 text-slate-600">{u.department}</td>
                    <td className="py-2 px-3">
                      <span className="text-emerald-700 font-semibold">啟用中</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Add Form */}
          {isAdding && (
            <form onSubmit={handleCreateUser} className="p-4 bg-slate-50 border border-slate-200 rounded-lg space-y-3">
              <h4 className="font-bold text-slate-800">建立新使用者帳號</h4>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 mb-1 font-semibold">登入帳號 *</label>
                  <input
                    type="text"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                    placeholder="例: packer02"
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded bg-white text-xs"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-700 mb-1 font-semibold">姓名 *</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="例: 王大明"
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded bg-white text-xs"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 mb-1 font-semibold">角色權限 *</label>
                  <select
                    value={formData.role}
                    onChange={(e) => setFormData({ ...formData, role: e.target.value as UserRole })}
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded bg-white text-xs"
                  >
                    <option value="operator">一般使用者 (包裝/理貨員)</option>
                    <option value="manager">主管 (審核/退回/作廢/報表)</option>
                    <option value="admin">管理員 (全部權限)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-700 mb-1 font-semibold">部門</label>
                  <input
                    type="text"
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded bg-white text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 mb-1 font-semibold">初始密碼 *</label>
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  placeholder="請輸入密碼"
                  className="w-full px-2.5 py-1.5 border border-slate-300 rounded bg-white text-xs"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAdding(false)}
                  className="px-3 py-1.5 border border-slate-300 rounded hover:bg-slate-100"
                >
                  取消
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 text-white rounded font-medium hover:bg-indigo-700"
                >
                  確認新增
                </button>
              </div>
            </form>
          )}

          {/* Reset Demo */}
          <div className="pt-4 border-t border-slate-200 flex justify-between items-center text-[11px] text-slate-500">
            <span>如需測試全新乾淨狀態，可一鍵重置資料庫：</span>
            <button
              onClick={handleResetDemoData}
              className="px-3 py-1 bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 rounded font-medium flex items-center gap-1"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              重置示範資料庫
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 bg-slate-50 border-t border-slate-200 flex justify-end text-xs">
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 text-white rounded-lg hover:bg-slate-900 font-medium"
          >
            關閉
          </button>
        </div>
      </div>
    </div>
  );
}

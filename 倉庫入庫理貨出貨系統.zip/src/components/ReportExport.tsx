import React, { useState, useEffect } from 'react';
import { MonthlyReportData, InboundRecord, OutboundRecord } from '../types/warehouse';
import { api } from '../lib/api';
import { Calendar, Download, Printer, TrendingUp, Package, ArrowUpRight, ArrowDownRight, RefreshCw } from 'lucide-react';

interface ReportExportProps {
  inboundRecords: InboundRecord[];
  outboundRecords: OutboundRecord[];
}

export function ReportExport({ inboundRecords, outboundRecords }: ReportExportProps) {
  const currentMonthStr = new Date().toISOString().substring(0, 7);
  const [selectedMonth, setSelectedMonth] = useState(currentMonthStr);
  const [reportData, setReportData] = useState<MonthlyReportData | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const fetchMonthlyData = async (month: string) => {
    try {
      setIsLoading(true);
      const data = await api.getMonthlyReport(month);
      setReportData(data);
    } catch (err: any) {
      console.error('Failed to load monthly report:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchMonthlyData(selectedMonth);
  }, [selectedMonth]);

  // Export functions
  const exportInboundMonthlyCSV = () => {
    const monthly = inboundRecords.filter(r => r.date.startsWith(selectedMonth));
    const headers = ['日期', '製令單號', '品名', '數量', '線材批號', '線徑(mm)', '設備編號', '包裝人員', '狀態', '審核主管', '備註'];
    const rows = monthly.map(r => [
      r.date,
      r.moNumber,
      r.productName,
      r.quantity,
      r.wireBatch,
      r.wireGauge.toFixed(3),
      r.machineId,
      r.packer,
      r.status,
      r.reviewerName || '',
      r.notes || ''
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
    downloadCSV(csvContent, `入庫月報表_${selectedMonth}.csv`);
  };

  const exportOutboundMonthlyCSV = () => {
    const monthly = outboundRecords.filter(r => r.date.startsWith(selectedMonth));
    const headers = ['出貨日期', '出貨單號', '客戶名稱', '品名', '出貨數量', '線材批號', '線徑(mm)', '理貨台', '理貨人員', '狀態', '扣帳狀態', '審核主管', '備註'];
    const rows = monthly.map(r => [
      r.date,
      r.shippingOrderNo,
      r.customerName,
      r.productName,
      r.quantity,
      r.wireBatch,
      r.wireGauge.toFixed(3),
      r.tallyStation || '',
      r.tallyPerson,
      r.status,
      r.stockDeducted ? '已扣帳' : '未扣帳',
      r.reviewerName || '',
      r.notes || ''
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
    downloadCSV(csvContent, `出貨理貨月報表_${selectedMonth}.csv`);
  };

  const exportProductSummaryCSV = () => {
    if (!reportData) return;
    const headers = ['品名規格', '當月入庫總量', '當月出貨扣帳總量', '當月庫存淨變動'];
    const rows = reportData.productBreakdown.map(p => [
      p.productName,
      p.inboundQty,
      p.outboundQty,
      p.inboundQty - p.outboundQty
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
    downloadCSV(csvContent, `各品名進出月彙總表_${selectedMonth}.csv`);
  };

  const downloadCSV = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Month Selector */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">月份統計與報表匯出</h2>
          <p className="text-xs text-slate-500 mt-1">
            統計各月核准生效之入庫與出貨扣帳總量，提供完整 Excel / CSV 匯出與列印功能。
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 bg-white border border-slate-300 rounded-lg px-3 py-1.5 shadow-xs">
            <Calendar className="w-4 h-4 text-slate-500" />
            <span className="text-xs text-slate-600 font-medium">統計月份:</span>
            <input
              type="month"
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="text-xs font-semibold text-slate-900 bg-transparent focus:outline-none"
            />
          </div>

          <button
            onClick={() => window.print()}
            className="px-3.5 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            列印月報表
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      {reportData && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <div className="text-xs font-medium text-slate-500">{selectedMonth} 月核准入庫總量</div>
            <div className="mt-2 flex items-baseline justify-between">
              <span className="font-mono text-2xl font-bold tracking-tight text-emerald-600 tabular-nums">
                +{reportData.totalInboundQty.toLocaleString()}
              </span>
              <span className="text-xs text-slate-400">PCS</span>
            </div>
            <div className="mt-2 text-[11px] text-slate-500">
              共 <span className="font-semibold text-slate-700">{reportData.inboundRecordCount}</span> 筆核准工單
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <div className="text-xs font-medium text-slate-500">{selectedMonth} 月核准出貨扣帳總量</div>
            <div className="mt-2 flex items-baseline justify-between">
              <span className="font-mono text-2xl font-bold tracking-tight text-rose-600 tabular-nums">
                -{reportData.totalOutboundQty.toLocaleString()}
              </span>
              <span className="text-xs text-slate-400">PCS</span>
            </div>
            <div className="mt-2 text-[11px] text-slate-500">
              共 <span className="font-semibold text-slate-700">{reportData.outboundRecordCount}</span> 筆出貨明細
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <div className="text-xs font-medium text-slate-500">{selectedMonth} 月庫存淨變動量</div>
            <div className="mt-2 flex items-baseline justify-between">
              <span className={`font-mono text-2xl font-bold tracking-tight tabular-nums ${
                reportData.netChange >= 0 ? 'text-indigo-600' : 'text-amber-600'
              }`}>
                {reportData.netChange > 0 ? `+${reportData.netChange.toLocaleString()}` : reportData.netChange.toLocaleString()}
              </span>
              <span className="text-xs text-slate-400">PCS</span>
            </div>
            <div className="mt-2 text-[11px] text-slate-500">
              {reportData.netChange >= 0 ? '當月入庫大於出貨，庫存增加' : '當月出貨大於入庫，庫存消化'}
            </div>
          </div>

          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
            <div className="text-xs font-medium text-slate-500">品名規格涵蓋數</div>
            <div className="mt-2 flex items-baseline justify-between">
              <span className="font-mono text-2xl font-bold tracking-tight text-slate-900 tabular-nums">
                {reportData.productBreakdown.length}
              </span>
              <span className="text-xs text-slate-400">項主要產品</span>
            </div>
            <div className="mt-2 text-[11px] text-slate-500">
              各線材型號均依批號個別扣帳
            </div>
          </div>
        </div>
      )}

      {/* CSV Export Button Strip */}
      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="font-semibold text-slate-700">快速下載當月報表資料檔 (支援 Excel 繁體中文)：</div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={exportInboundMonthlyCSV}
            className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 font-medium text-slate-700 flex items-center gap-1.5 shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-indigo-600" />
            入庫月報表 (.CSV)
          </button>
          <button
            onClick={exportOutboundMonthlyCSV}
            className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 font-medium text-slate-700 flex items-center gap-1.5 shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-indigo-600" />
            出貨扣帳月報表 (.CSV)
          </button>
          <button
            onClick={exportProductSummaryCSV}
            className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg hover:bg-slate-100 font-medium text-slate-700 flex items-center gap-1.5 shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-indigo-600" />
            各品名彙總表 (.CSV)
          </button>
        </div>
      </div>

      {/* Product Summary Table */}
      {reportData && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200">
            <h3 className="font-bold text-slate-800 text-sm">各品名出入庫月度統計彙總</h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100/60 border-b border-slate-200 text-slate-600 font-semibold uppercase">
                <tr>
                  <th className="py-3 px-4">品名規格</th>
                  <th className="py-3 px-4 text-right">當月核准入庫量</th>
                  <th className="py-3 px-4 text-right">當月核准出貨扣帳量</th>
                  <th className="py-3 px-4 text-right">當月淨變動</th>
                  <th className="py-3 px-4">佔比與趨勢狀態</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {reportData.productBreakdown.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-slate-400">
                      該月份尚無已核准的進出紀錄
                    </td>
                  </tr>
                ) : (
                  reportData.productBreakdown.map((p, idx) => {
                    const net = p.inboundQty - p.outboundQty;
                    return (
                      <tr key={idx} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3 px-4 font-bold text-slate-900">{p.productName}</td>
                        <td className="py-3 px-4 text-right font-mono text-emerald-600 font-semibold tabular-nums">
                          +{p.inboundQty.toLocaleString()}
                        </td>
                        <td className="py-3 px-4 text-right font-mono text-rose-600 font-semibold tabular-nums">
                          -{p.outboundQty.toLocaleString()}
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-bold tabular-nums">
                          <span className={net >= 0 ? 'text-indigo-600' : 'text-amber-600'}>
                            {net > 0 ? `+${net.toLocaleString()}` : net.toLocaleString()}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <div className="w-24 bg-slate-100 h-2 rounded-full overflow-hidden flex">
                              <div
                                style={{ width: `${Math.min(100, (p.inboundQty / (reportData.totalInboundQty || 1)) * 100)}%` }}
                                className="bg-emerald-500 h-full"
                              />
                            </div>
                            <span className="font-mono text-[11px] text-slate-500">
                              {((p.inboundQty / (reportData.totalInboundQty || 1)) * 100).toFixed(0)}% 入庫
                            </span>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Daily Trend List */}
      {reportData && reportData.dailyTrend.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="px-5 py-3.5 bg-slate-50 border-b border-slate-200">
            <h3 className="font-bold text-slate-800 text-sm">{selectedMonth} 月每日進出日報趨勢</h3>
          </div>
          <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
            {reportData.dailyTrend.map((d) => (
              <div key={d.date} className="p-3 bg-slate-50 rounded-lg border border-slate-200 flex items-center justify-between">
                <span className="font-mono font-semibold text-slate-800">{d.date}</span>
                <div className="flex items-center gap-4 font-mono text-xs">
                  <span className="text-emerald-600 font-semibold">入庫: +{d.inboundQty.toLocaleString()}</span>
                  <span className="text-rose-600 font-semibold">出貨: -{d.outboundQty.toLocaleString()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

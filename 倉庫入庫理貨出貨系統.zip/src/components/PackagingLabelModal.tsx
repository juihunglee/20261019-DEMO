import React, { useRef } from 'react';
import { InboundRecord, OutboundRecord } from '../types/warehouse';
import { BarcodeSVG, QRCodeSVG } from './BarcodeGenerator';
import { Printer, X, CheckCircle, ShieldCheck } from 'lucide-react';

interface PackagingLabelModalProps {
  inboundRecord?: InboundRecord | null;
  outboundRecord?: OutboundRecord | null;
  onClose: () => void;
}

export function PackagingLabelModal({ inboundRecord, outboundRecord, onClose }: PackagingLabelModalProps) {
  const isOutbound = !!outboundRecord;
  const printAreaRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    window.print();
  };

  const title = isOutbound ? '客戶專用出貨理貨標籤' : '工廠包裝入庫成品標籤';
  const docNo = isOutbound ? outboundRecord.shippingOrderNo : inboundRecord?.moNumber;
  const productName = isOutbound ? outboundRecord.productName : inboundRecord?.productName;
  const quantity = isOutbound ? outboundRecord.quantity : inboundRecord?.quantity;
  const wireBatch = isOutbound ? outboundRecord.wireBatch : inboundRecord?.wireBatch;
  const wireGauge = isOutbound ? outboundRecord.wireGauge : inboundRecord?.wireGauge;
  const date = isOutbound ? outboundRecord.date : inboundRecord?.date;
  const operatorName = isOutbound ? outboundRecord.tallyPerson : inboundRecord?.packer;
  const stationOrMachine = isOutbound ? (outboundRecord.tallyStation || '理貨區') : inboundRecord?.machineId;
  const extraParty = isOutbound ? `客戶: ${outboundRecord.customerName}` : `製令工單: ${inboundRecord?.moNumber}`;
  const status = isOutbound ? outboundRecord.status : inboundRecord?.status;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 overflow-y-auto">
      <div className="relative w-full max-w-xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Modal Header */}
        <div className="no-print flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-2">
            <Printer className="w-5 h-5 text-indigo-600" />
            <h3 className="font-semibold text-slate-900 text-base">{title}預覽與列印</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body: Printable Label Container */}
        <div className="p-6 bg-slate-100 flex justify-center">
          <div
            ref={printAreaRef}
            className="w-full max-w-md bg-white border-2 border-slate-900 p-5 shadow-sm text-slate-900 font-sans print:border-2 print:border-black print:shadow-none print:w-[100mm] print:h-[80mm] print:p-3"
          >
            {/* Label Top Bar */}
            <div className="flex justify-between items-start border-b-2 border-slate-900 pb-2 mb-3">
              <div>
                <h4 className="text-base font-bold tracking-tight text-slate-900 leading-tight">
                  {isOutbound ? '線材成品客戶出貨專用標籤' : '線材成品包裝合格入庫標籤'}
                </h4>
                <p className="text-[11px] text-slate-600 mt-0.5">
                  {extraParty} · 規格合格認證
                </p>
              </div>
              <div className="text-right">
                <span className="inline-block px-1.5 py-0.5 text-[10px] font-bold border border-slate-900 uppercase">
                  {status === 'APPROVED' ? '已審核合格' : '包裝點收中'}
                </span>
                <p className="font-mono text-[10px] text-slate-500 mt-0.5">{date}</p>
              </div>
            </div>

            {/* Barcode Section */}
            <div className="flex justify-between items-center my-3 py-1 bg-slate-50 border border-dashed border-slate-300 px-3">
              <BarcodeSVG value={docNo || 'NO-CODE'} height={40} className="flex-1" />
              <div className="ml-3 pl-3 border-l border-slate-300">
                <QRCodeSVG value={`${docNo}|${productName}|${wireBatch}|${quantity}PCS`} size={64} />
              </div>
            </div>

            {/* Specifications Grid Table */}
            <table className="w-full text-xs border-collapse border border-slate-800 my-2">
              <tbody>
                <tr className="border-b border-slate-800">
                  <td className="bg-slate-100 font-semibold p-1.5 border-r border-slate-800 w-24">品名規格</td>
                  <td className="p-1.5 font-bold text-slate-900">{productName}</td>
                </tr>
                <tr className="border-b border-slate-800">
                  <td className="bg-slate-100 font-semibold p-1.5 border-r border-slate-800">包裝數量</td>
                  <td className="p-1.5 font-mono font-bold text-slate-900 tabular-nums">
                    {quantity?.toLocaleString()} <span className="text-[10px] font-normal text-slate-600">PCS / 軸</span>
                  </td>
                </tr>
                <tr className="border-b border-slate-800">
                  <td className="bg-slate-100 font-semibold p-1.5 border-r border-slate-800">線材批號</td>
                  <td className="p-1.5 font-mono font-semibold text-slate-800">{wireBatch}</td>
                </tr>
                <tr className="border-b border-slate-800">
                  <td className="bg-slate-100 font-semibold p-1.5 border-r border-slate-800">線徑規格</td>
                  <td className="p-1.5 font-mono text-slate-900">
                    <span className="font-bold">{wireGauge?.toFixed(3)}</span> mm
                  </td>
                </tr>
                <tr className="border-b border-slate-800">
                  <td className="bg-slate-100 font-semibold p-1.5 border-r border-slate-800">
                    {isOutbound ? '理貨台位' : '生產設備'}
                  </td>
                  <td className="p-1.5 font-mono">{stationOrMachine}</td>
                </tr>
                <tr>
                  <td className="bg-slate-100 font-semibold p-1.5 border-r border-slate-800">
                    {isOutbound ? '理貨覆核' : '包裝作業員'}
                  </td>
                  <td className="p-1.5 flex items-center justify-between">
                    <span>{operatorName}</span>
                    <span className="text-[10px] text-emerald-700 font-bold flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" /> 檢驗合格 (QA PASS)
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>

            {/* Footer warning */}
            <div className="mt-2 text-[10px] text-slate-500 flex justify-between items-center">
              <span>* 本批線材已依規範防潮包裝，拆封後請於 48 小時內加工。</span>
              <span className="font-mono text-[9px]">REV 2.0</span>
            </div>
          </div>
        </div>

        {/* Modal Footer Controls */}
        <div className="no-print flex items-center justify-between px-6 py-4 border-t border-slate-200 bg-white">
          <span className="text-xs text-slate-500">
            支援標準標籤機 (TSC / Zebra 100×80mm) 及一般 A4 印表機
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
            >
              關閉
            </button>
            <button
              onClick={handlePrint}
              className="px-4 py-2 text-xs font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors flex items-center gap-1.5 shadow-sm"
            >
              <Printer className="w-4 h-4" />
              列印標籤
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

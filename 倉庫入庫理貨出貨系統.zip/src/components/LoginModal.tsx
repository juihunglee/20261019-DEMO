import React, { useState } from 'react';
import { ShieldCheck, Lock, User as UserIcon, AlertCircle, ArrowRight } from 'lucide-react';

interface LoginModalProps {
  onLogin: (username: string, pwd: string) => Promise<void>;
  isLoading: boolean;
  errorMessage?: string;
}

export function LoginModal({ onLogin, isLoading, errorMessage }: LoginModalProps) {
  const [username, setUsername] = useState('operator');
  const [password, setPassword] = useState('operator123');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password) return;
    onLogin(username.trim(), password);
  };

  const handleQuickFill = (u: string, p: string) => {
    setUsername(u);
    setPassword(p);
    onLogin(u, p);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 p-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="bg-slate-900 text-white p-6 text-center">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-indigo-500/20 text-indigo-400 mb-3 border border-indigo-500/30">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h2 className="text-xl font-bold tracking-tight">倉庫入庫理貨出貨系統</h2>
          <p className="text-xs text-slate-400 mt-1">線材製造工廠專用 · 自動扣帳庫存與標籤列印</p>
        </div>

        {/* Form Body */}
        <div className="p-6">
          {errorMessage && (
            <div className="mb-4 p-3 rounded-lg bg-rose-50 border border-rose-200 flex items-start gap-2 text-rose-700 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                使用者帳號
              </label>
              <div className="relative">
                <UserIcon className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="請輸入帳號"
                  required
                  className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                密碼
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="請輸入密碼"
                  required
                  className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 bg-white"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold rounded-lg shadow-sm transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {isLoading ? '登入驗證中...' : '安全登入系統'}
              {!isLoading && <ArrowRight className="w-4 h-4" />}
            </button>
          </form>

          {/* Quick Demo Switcher Buttons */}
          <div className="mt-6 pt-5 border-t border-slate-200">
            <div className="text-[11px] font-semibold text-slate-500 mb-2.5 text-center">
              一鍵示範登入（各角色預設帳號）
            </div>
            <div className="grid grid-cols-1 gap-1.5">
              <button
                type="button"
                onClick={() => handleQuickFill('operator', 'operator123')}
                className="w-full py-1.5 px-3 rounded-lg border border-slate-200 hover:bg-indigo-50 hover:border-indigo-200 text-xs text-left text-slate-700 flex items-center justify-between transition-colors"
              >
                <span>
                  <strong className="text-indigo-900">陳作業 (一般使用者)</strong> · 包裝日報、理貨、標籤
                </span>
                <span className="text-[10px] text-slate-400 font-mono">operator</span>
              </button>
              <button
                type="button"
                onClick={() => handleQuickFill('manager', 'manager123')}
                className="w-full py-1.5 px-3 rounded-lg border border-slate-200 hover:bg-amber-50 hover:border-amber-200 text-xs text-left text-slate-700 flex items-center justify-between transition-colors"
              >
                <span>
                  <strong className="text-amber-900">張主管 (審核主管)</strong> · 入庫/出貨審核、退回作廢、報表
                </span>
                <span className="text-[10px] text-slate-400 font-mono">manager</span>
              </button>
              <button
                type="button"
                onClick={() => handleQuickFill('admin', 'admin123')}
                className="w-full py-1.5 px-3 rounded-lg border border-slate-200 hover:bg-slate-100 text-xs text-left text-slate-700 flex items-center justify-between transition-colors"
              >
                <span>
                  <strong className="text-slate-900">林管理 (系統管理員)</strong> · 帳號管理、稽核日誌、全系統
                </span>
                <span className="text-[10px] text-slate-400 font-mono">admin</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

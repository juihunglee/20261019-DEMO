import React from 'react';
import { User, UserRole } from '../types/warehouse';
import { LogOut, UserCheck, Shield, FileText, Layers, RefreshCw } from 'lucide-react';

interface HeaderProps {
  currentUser: User | null;
  activeTab: 'inbound' | 'outbound' | 'inventory' | 'approval' | 'reports';
  setActiveTab: (tab: 'inbound' | 'outbound' | 'inventory' | 'approval' | 'reports') => void;
  onLogout: () => void;
  onOpenAuditLogs: () => void;
  onOpenUserManagement: () => void;
  onSwitchUserQuick?: (role: UserRole) => void;
  pendingReviewCount: number;
}

export function Header({
  currentUser,
  activeTab,
  setActiveTab,
  onLogout,
  onOpenAuditLogs,
  onOpenUserManagement,
  onSwitchUserQuick,
  pendingReviewCount
}: HeaderProps) {
  const roleNameMap: Record<UserRole, string> = {
    admin: '系統管理員',
    manager: '生管主管',
    operator: '包裝理貨員'
  };

  return (
    <header className="no-print bg-white border-b border-slate-200 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single text wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-bold text-sm shadow-sm">
              WMS
            </div>
            <a
              href="#"
              onClick={(e) => { e.preventDefault(); setActiveTab('inbound'); }}
              className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 hover:text-indigo-600 transition-colors"
            >
              倉庫入庫理貨出貨系統
            </a>
          </div>

          {/* Zone 2: Navigation Links (4-5 single-line clean text links) */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <button
              onClick={() => setActiveTab('inbound')}
              className={`whitespace-nowrap shrink-0 py-1 transition-colors ${
                activeTab === 'inbound'
                  ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600'
                  : 'hover:text-slate-900'
              }`}
            >
              包裝入庫日報
            </button>
            <button
              onClick={() => setActiveTab('outbound')}
              className={`whitespace-nowrap shrink-0 py-1 transition-colors ${
                activeTab === 'outbound'
                  ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600'
                  : 'hover:text-slate-900'
              }`}
            >
              理貨與出貨扣帳
            </button>
            <button
              onClick={() => setActiveTab('inventory')}
              className={`whitespace-nowrap shrink-0 py-1 transition-colors ${
                activeTab === 'inventory'
                  ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600'
                  : 'hover:text-slate-900'
              }`}
            >
              即時在庫看板
            </button>
            <button
              onClick={() => setActiveTab('approval')}
              className={`whitespace-nowrap shrink-0 py-1 transition-colors relative ${
                activeTab === 'approval'
                  ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600'
                  : 'hover:text-slate-900'
              }`}
            >
              主管審核簽核
              {pendingReviewCount > 0 && (
                <span className="ml-1.5 px-1.5 py-0.2 text-[10px] font-bold rounded-full bg-amber-500 text-white font-mono">
                  {pendingReviewCount}
                </span>
              )}
            </button>
            <button
              onClick={() => setActiveTab('reports')}
              className={`whitespace-nowrap shrink-0 py-1 transition-colors ${
                activeTab === 'reports'
                  ? 'text-indigo-600 font-semibold border-b-2 border-indigo-600'
                  : 'hover:text-slate-900'
              }`}
            >
              月份統計與匯出
            </button>
          </nav>

          {/* Zone 3: User Profile & Actions */}
          <div className="flex items-center gap-3 shrink-0">
            {currentUser ? (
              <div className="flex items-center gap-3">
                {/* Role Switcher for quick test/evaluation */}
                {onSwitchUserQuick && (
                  <div className="hidden lg:flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs">
                    <span className="text-slate-400 px-1.5 text-[11px]">切換角色:</span>
                    <button
                      onClick={() => onSwitchUserQuick('operator')}
                      className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                        currentUser.role === 'operator' ? 'bg-white shadow-xs text-indigo-700 font-bold' : 'text-slate-600 hover:text-slate-900'
                      }`}
                      title="一般使用者：新增修改自己資料、標籤列印"
                    >
                      一般人員
                    </button>
                    <button
                      onClick={() => onSwitchUserQuick('manager')}
                      className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                        currentUser.role === 'manager' ? 'bg-white shadow-xs text-indigo-700 font-bold' : 'text-slate-600 hover:text-slate-900'
                      }`}
                      title="主管：審核、退回、作廢、匯出報表"
                    >
                      主管
                    </button>
                    <button
                      onClick={() => onSwitchUserQuick('admin')}
                      className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                        currentUser.role === 'admin' ? 'bg-white shadow-xs text-indigo-700 font-bold' : 'text-slate-600 hover:text-slate-900'
                      }`}
                      title="管理員：帳號設定、稽核紀錄、全部資料"
                    >
                      管理員
                    </button>
                  </div>
                )}

                {/* Audit Log / Admin Tools */}
                {(currentUser.role === 'admin' || currentUser.role === 'manager') && (
                  <button
                    onClick={onOpenAuditLogs}
                    className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors text-xs flex items-center gap-1"
                    title="操作稽核日誌"
                  >
                    <FileText className="w-4 h-4" />
                    <span className="hidden xl:inline">稽核日誌</span>
                  </button>
                )}

                {currentUser.role === 'admin' && (
                  <button
                    onClick={onOpenUserManagement}
                    className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors text-xs flex items-center gap-1"
                    title="帳號權限管理"
                  >
                    <Shield className="w-4 h-4" />
                    <span className="hidden xl:inline">帳號管理</span>
                  </button>
                )}

                {/* Current User Badge */}
                <div className="flex items-center gap-2 pl-2 border-l border-slate-200">
                  <div className="w-7 h-7 rounded-full bg-slate-200 flex items-center justify-center text-slate-700 font-semibold text-xs">
                    {currentUser.name.charAt(0)}
                  </div>
                  <div className="hidden sm:block text-left text-xs leading-tight">
                    <div className="font-semibold text-slate-900">{currentUser.name}</div>
                    <div className="text-[11px] text-indigo-600">{roleNameMap[currentUser.role]}</div>
                  </div>
                </div>

                {/* Logout Button */}
                <button
                  onClick={onLogout}
                  className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                  title="登出系統"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => {}}
                className="px-4 py-2 text-xs font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors whitespace-nowrap shrink-0"
              >
                登入系統
              </button>
            )}
          </div>
        </div>

        {/* Mobile Navigation Bar */}
        <div className="md:hidden flex overflow-x-auto gap-2 py-2 border-t border-slate-100 text-xs">
          <button
            onClick={() => setActiveTab('inbound')}
            className={`px-3 py-1.5 rounded whitespace-nowrap ${
              activeTab === 'inbound' ? 'bg-indigo-50 text-indigo-700 font-bold' : 'text-slate-600'
            }`}
          >
            包裝入庫
          </button>
          <button
            onClick={() => setActiveTab('outbound')}
            className={`px-3 py-1.5 rounded whitespace-nowrap ${
              activeTab === 'outbound' ? 'bg-indigo-50 text-indigo-700 font-bold' : 'text-slate-600'
            }`}
          >
            理貨出貨
          </button>
          <button
            onClick={() => setActiveTab('inventory')}
            className={`px-3 py-1.5 rounded whitespace-nowrap ${
              activeTab === 'inventory' ? 'bg-indigo-50 text-indigo-700 font-bold' : 'text-slate-600'
            }`}
          >
            即時庫存
          </button>
          <button
            onClick={() => setActiveTab('approval')}
            className={`px-3 py-1.5 rounded whitespace-nowrap ${
              activeTab === 'approval' ? 'bg-indigo-50 text-indigo-700 font-bold' : 'text-slate-600'
            }`}
          >
            審核簽核 ({pendingReviewCount})
          </button>
          <button
            onClick={() => setActiveTab('reports')}
            className={`px-3 py-1.5 rounded whitespace-nowrap ${
              activeTab === 'reports' ? 'bg-indigo-50 text-indigo-700 font-bold' : 'text-slate-600'
            }`}
          >
            統計報表
          </button>
        </div>
      </div>
    </header>
  );
}

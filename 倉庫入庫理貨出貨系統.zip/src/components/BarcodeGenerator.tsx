import React from 'react';

// Generates an industrial-styled Code 128 pseudo barcode rendered in crisp SVG
export function BarcodeSVG({ value, height = 48, className = '' }: { value: string; height?: number; className?: string }) {
  // Deterministic bar widths based on char codes
  const bars: { width: number; space: number }[] = [];
  let seed = 0;
  for (let i = 0; i < value.length; i++) {
    seed = (seed * 31 + value.charCodeAt(i)) % 100000;
  }

  // Guard rails
  bars.push({ width: 3, space: 2 });
  bars.push({ width: 1, space: 1 });
  bars.push({ width: 2, space: 3 });

  for (let i = 0; i < value.length; i++) {
    const code = value.charCodeAt(i);
    const w1 = ((code * 7 + i) % 3) + 1;
    const s1 = ((code * 13 + i * 2) % 3) + 1;
    const w2 = ((code * 19 + i * 3) % 4) + 1;
    const s2 = ((code * 23 + i * 5) % 3) + 1;
    bars.push({ width: w1, space: s1 });
    bars.push({ width: w2, space: s2 });
  }

  bars.push({ width: 3, space: 1 });
  bars.push({ width: 1, space: 2 });
  bars.push({ width: 3, space: 0 });

  let currentX = 0;
  const elements = bars.map((b, idx) => {
    const rectX = currentX;
    currentX += b.width + b.space;
    return (
      <rect key={idx} x={rectX} y={0} width={b.width} height={height} fill="currentColor" />
    );
  });

  return (
    <div className={`flex flex-col items-center ${className}`}>
      <svg
        viewBox={`0 0 ${currentX} ${height}`}
        style={{ width: '100%', maxWidth: `${Math.min(currentX * 1.5, 260)}px`, height: `${height}px` }}
        className="text-slate-900"
      >
        {elements}
      </svg>
      <span className="font-mono text-[11px] tracking-widest text-slate-700 mt-1">{value}</span>
    </div>
  );
}

// Generates a crisp SVG 2D QR Code Matrix
export function QRCodeSVG({ value, size = 96, className = '' }: { value: string; size?: number; className?: string }) {
  const gridSize = 21;
  const matrix: boolean[][] = Array.from({ length: gridSize }, () => Array(gridSize).fill(false));

  // Finder patterns at three corners (7x7)
  const placeFinder = (startX: number, startY: number) => {
    for (let y = 0; y < 7; y++) {
      for (let x = 0; x < 7; x++) {
        if (
          x === 0 || x === 6 || y === 0 || y === 6 ||
          (x >= 2 && x <= 4 && y >= 2 && y <= 4)
        ) {
          matrix[startY + y][startX + x] = true;
        }
      }
    }
  };

  placeFinder(0, 0);
  placeFinder(gridSize - 7, 0);
  placeFinder(0, gridSize - 7);

  // Timing patterns
  for (let i = 8; i < gridSize - 8; i++) {
    if (i % 2 === 0) {
      matrix[6][i] = true;
      matrix[i][6] = true;
    }
  }

  // Deterministic data fill based on value string
  let hash = 0;
  for (let i = 0; i < value.length; i++) {
    hash = (hash * 37 + value.charCodeAt(i)) & 0xffffffff;
  }

  for (let y = 0; y < gridSize; y++) {
    for (let x = 0; x < gridSize; x++) {
      // Don't overwrite finders
      const inTopLeft = x < 8 && y < 8;
      const inTopRight = x >= gridSize - 8 && y < 8;
      const inBottomLeft = x < 8 && y >= gridSize - 8;
      if (!inTopLeft && !inTopRight && !inBottomLeft && !(x === 6 || y === 6)) {
        hash = (hash * 1103515245 + 12345) & 0x7fffffff;
        if (hash % 3 === 0) {
          matrix[y][x] = true;
        }
      }
    }
  }

  const cellSize = size / gridSize;

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className={className}>
      <rect width={size} height={size} fill="#ffffff" />
      {matrix.map((row, y) =>
        row.map((cell, x) =>
          cell ? (
            <rect
              key={`${x}-${y}`}
              x={x * cellSize}
              y={y * cellSize}
              width={cellSize + 0.2}
              height={cellSize + 0.2}
              fill="#0f172a"
            />
          ) : null
        )
      )}
    </svg>
  );
}

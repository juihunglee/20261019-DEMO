import React, { useState, useMemo } from 'react';
import { InboundRecord, User, RecordStatus } from '../types/warehouse';
import {
  Plus, Search, Filter, Printer, Edit2, Trash2, Send,
  AlertCircle, CheckCircle2, Clock, XCircle, RotateCcw, ChevronLeft, ChevronRight
} from 'lucide-react';

interface InboundManagementProps {
  records: InboundRecord[];
  currentUser: User;
  onRefresh: () => void;
  onCreate: (data: any) => Promise<void>;
  onUpdate: (id: string, data: any) => Promise<void>;
  onAction: (id: string, action: 'SUBMIT' | 'APPROVE' | 'REJECT' | 'VOID' | 'RESUBMIT', note?: string) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
  onOpenLabel: (record: InboundRecord) => void;
}

export function InboundManagement({
  records,
  currentUser,
  onRefresh,
  onCreate,
  onUpdate,
  onAction,
  onDelete,
  onOpenLabel
}: InboundManagementProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [myOnly, setMyOnly] = useState(false);

  // Form modal state
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<InboundRecord | null>(null);
  const [formData, setFormData] = useState({
    date: new Date().toISOString().substring(0, 10),
    moNumber: '',
    productName: '無氧銅精拉線',
    quantity: 1000,
    wireBatch: '',
    wireGauge: 0.85,
    machineId: 'LINE-01',
    packer: currentUser.name,
    notes: '',
    autoSubmit: true
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Detail / Review view modal
  const [selectedRecordForDetail, setSelectedRecordForDetail] = useState<InboundRecord | null>(null);

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;

  // Filtered records
  const filteredRecords = useMemo(() => {
    return records.filter(r => {
      if (myOnly && r.createdById !== currentUser.id) return false;
      if (statusFilter !== 'ALL' && r.status !== statusFilter) return false;
      if (startDate && r.date < startDate) return false;
      if (endDate && r.date > endDate) return false;
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        const matchMo = r.moNumber.toLowerCase().includes(q);
        const matchProd = r.productName.toLowerCase().includes(q);
        const matchBatch = r.wireBatch.toLowerCase().includes(q);
        const matchMachine = r.machineId.toLowerCase().includes(q);
        const matchPacker = r.packer.toLowerCase().includes(q);
        if (!matchMo && !matchProd && !matchBatch && !matchMachine && !matchPacker) return false;
      }
      return true;
    });
  }, [records, myOnly, currentUser.id, statusFilter, startDate, endDate, searchTerm]);

  const totalPages = Math.max(1, Math.ceil(filteredRecords.length / pageSize));
  const paginatedRecords = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredRecords.slice(start, start + pageSize);
  }, [filteredRecords, currentPage]);

  const handleOpenCreate = () => {
    const today = new Date().toISOString().substring(0, 10);
    const randomSuffix = Math.floor(10 + Math.random() * 90);
    setEditingRecord(null);
    setFormData({
      date: today,
      moNumber: `MO-${today.replace(/-/g, '')}-${randomSuffix}`,
      productName: '無氧銅精拉線',
      quantity: 2000,
      wireBatch: `LOT-CU-${today.substring(2, 7).replace('-', '')}`,
      wireGauge: 0.85,
      machineId: 'LINE-01',
      packer: currentUser.name,
      notes: '',
      autoSubmit: true
    });
    setFormErrors({});
    setIsFormOpen(true);
  };

  const handleOpenEdit = (rec: InboundRecord) => {
    setEditingRecord(rec);
    setFormData({
      date: rec.date,
      moNumber: rec.moNumber,
      productName: rec.productName,
      quantity: rec.quantity,
      wireBatch: rec.wireBatch,
      wireGauge: rec.wireGauge,
      machineId: rec.machineId,
      packer: rec.packer,
      notes: rec.notes || '',
      autoSubmit: rec.status === 'REJECTED' // if editing a rejected record, default to resubmitting
    });
    setFormErrors({});
    setIsFormOpen(true);
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};
    if (!formData.date) errors.date = '請選擇日期';
    if (!formData.moNumber.trim()) errors.moNumber = '請輸入製令單號';
    if (!formData.productName.trim()) errors.productName = '請輸入品名';
    if (!formData.quantity || formData.quantity <= 0) errors.quantity = '數量必須為大於 0 的正整數';
    if (!formData.wireBatch.trim()) errors.wireBatch = '請輸入線材批號';
    if (!formData.wireGauge || formData.wireGauge <= 0) errors.wireGauge = '請輸入有效線徑 (mm)';
    if (!formData.machineId.trim()) errors.machineId = '請輸入設備編號';
    if (!formData.packer.trim()) errors.packer = '請輸入包裝人員';
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    try {
      setIsSubmitting(true);
      if (editingRecord) {
        await onUpdate(editingRecord.id, {
          ...formData,
          resubmit: formData.autoSubmit
        });
      } else {
        await onCreate(formData);
      }
      setIsFormOpen(false);
      onRefresh();
    } catch (err: any) {
      alert(err.message || '儲存失敗');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteRecord = async (id: string, mo: string) => {
    if (window.confirm(`確定要刪除製令單號【${mo}】的入庫紀錄嗎？此動作將記入操作稽核日誌。`)) {
      try {
        await onDelete(id);
        onRefresh();
      } catch (err: any) {
        alert(err.message || '刪除失敗');
      }
    }
  };

  const handleDirectSubmit = async (id: string) => {
    if (window.confirm('確定要送交主管審核此入庫單嗎？')) {
      try {
        await onAction(id, 'SUBMIT');
        onRefresh();
      } catch (err: any) {
        alert(err.message || '送審失敗');
      }
    }
  };

  const statusBadge = (status: RecordStatus) => {
    switch (status) {
      case 'DRAFT':
        return <span className="text-slate-600 font-medium">草稿</span>;
      case 'PENDING':
        return <span className="text-amber-700 font-semibold flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> 待審核</span>;
      case 'APPROVED':
        return <span className="text-emerald-700 font-bold flex items-center gap-1"><CheckCircle2 className="w-3.5 h-3.5" /> 已審核入庫</span>;
      case 'REJECTED':
        return <span className="text-rose-700 font-semibold flex items-center gap-1"><AlertCircle className="w-3.5 h-3.5" /> 已退回</span>;
      case 'VOIDED':
        return <span className="text-slate-400 font-medium line-through">已作廢</span>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Top action row */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">包裝日報與入庫管理</h2>
          <p className="text-xs text-slate-500 mt-1">
            現場包裝人員填報包裝日報表記錄入庫、列印成品條碼標籤，經主管審核後正式增加在庫庫存。
          </p>
        </div>

        <button
          onClick={handleOpenCreate}
          className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors flex items-center gap-1.5 shadow-sm shrink-0"
        >
          <Plus className="w-4 h-4" />
          新增包裝日報 (入庫)
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[280px]">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => { setSearchTerm(e.target.value); setCurrentPage(1); }}
              placeholder="搜尋製令單號、品名、線材批號、機台、包裝人員..."
              className="w-full pl-9 pr-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-indigo-500 bg-slate-50 text-xs"
            />
          </div>

          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value); setCurrentPage(1); }}
            className="px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-slate-700 focus:outline-none"
          >
            <option value="ALL">全部狀態</option>
            <option value="DRAFT">草稿</option>
            <option value="PENDING">待審核</option>
            <option value="APPROVED">已審核 (入庫成功)</option>
            <option value="REJECTED">已退回</option>
            <option value="VOIDED">已作廢</option>
          </select>

          <input
            type="date"
            value={startDate}
            onChange={(e) => { setStartDate(e.target.value); setCurrentPage(1); }}
            title="起始日期"
            className="px-2.5 py-1.5 border border-slate-200 rounded-lg bg-slate-50 text-slate-700 text-xs"
          />
          <span className="text-slate-400">~</span>
          <input
            type="date"
            value={endDate}
            onChange={(e) => { setEndDate(e.target.value); setCurrentPage(1); }}
            title="結束日期"
            className="px-2.5 py-1.5 border border-slate-200 rounded-lg bg-slate-50 text-slate-700 text-xs"
          />
        </div>

        <div className="flex items-center gap-3">
          <label className="flex items-center gap-1.5 cursor-pointer text-slate-600">
            <input
              type="checkbox"
              checked={myOnly}
              onChange={(e) => { setMyOnly(e.target.checked); setCurrentPage(1); }}
              className="rounded text-indigo-600 focus:ring-indigo-500 w-3.5 h-3.5"
            />
            <span>僅顯示我建立的</span>
          </label>

          {(searchTerm || statusFilter !== 'ALL' || startDate || endDate || myOnly) && (
            <button
              onClick={() => {
                setSearchTerm('');
                setStatusFilter('ALL');
                setStartDate('');
                setEndDate('');
                setMyOnly(false);
                setCurrentPage(1);
              }}
              className="text-indigo-600 hover:text-indigo-800 underline text-xs ml-1"
            >
              重設篩選
            </button>
          )}
        </div>
      </div>

      {/* Inbound Records Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">日期</th>
                <th className="py-3 px-4">製令單號</th>
                <th className="py-3 px-4">品名規格</th>
                <th className="py-3 px-4 text-right">數量</th>
                <th className="py-3 px-4">線材批號</th>
                <th className="py-3 px-4">線徑 (mm)</th>
                <th className="py-3 px-4">設備</th>
                <th className="py-3 px-4">包裝員</th>
                <th className="py-3 px-4">狀態</th>
                <th className="py-3 px-4 text-right">操作</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {paginatedRecords.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-12 text-center text-slate-400">
                    <p className="text-sm">尚無符合條件的包裝入庫紀錄</p>
                    <p className="text-xs mt-1">請點擊上方「新增包裝日報 (入庫)」建立第一筆紀錄</p>
                  </td>
                </tr>
              ) : (
                paginatedRecords.map((rec) => {
                  const canEdit =
                    currentUser.role === 'admin' ||
                    (currentUser.id === rec.createdById && (rec.status === 'DRAFT' || rec.status === 'REJECTED'));
                  const canDelete =
                    currentUser.role === 'admin' ||
                    (currentUser.id === rec.createdById && rec.status === 'DRAFT');

                  return (
                    <tr key={rec.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-4 font-mono text-slate-700">{rec.date}</td>
                      <td className="py-3 px-4 font-mono font-medium text-slate-900">
                        {rec.moNumber}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900">{rec.productName}</div>
                        {rec.notes && <div className="text-[11px] text-slate-400 truncate max-w-xs">{rec.notes}</div>}
                        {rec.status === 'REJECTED' && rec.reviewNotes && (
                          <div className="text-[11px] text-rose-600 font-medium mt-0.5">
                            退回原因: {rec.reviewNotes}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold tabular-nums text-slate-900">
                        {rec.quantity.toLocaleString()}
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-700">{rec.wireBatch}</td>
                      <td className="py-3 px-4 font-mono text-slate-800">{rec.wireGauge.toFixed(3)}</td>
                      <td className="py-3 px-4 font-mono text-slate-600">{rec.machineId}</td>
                      <td className="py-3 px-4 text-slate-700">{rec.packer}</td>
                      <td className="py-3 px-4">{statusBadge(rec.status)}</td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Print Label */}
                          <button
                            onClick={() => onOpenLabel(rec)}
                            title="預覽與列印包裝標籤"
                            className="p-1.5 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded transition-colors"
                          >
                            <Printer className="w-3.5 h-3.5" />
                          </button>

                          {/* Submit from draft */}
                          {rec.status === 'DRAFT' && (
                            <button
                              onClick={() => handleDirectSubmit(rec.id)}
                              title="送交主管審核"
                              className="p-1.5 text-amber-600 hover:text-amber-800 hover:bg-amber-50 rounded transition-colors"
                            >
                              <Send className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* Resubmit from rejected */}
                          {rec.status === 'REJECTED' && canEdit && (
                            <button
                              onClick={() => handleOpenEdit(rec)}
                              title="修改並重新送審"
                              className="p-1.5 text-rose-600 hover:text-rose-800 hover:bg-rose-50 rounded transition-colors"
                            >
                              <RotateCcw className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* Edit */}
                          {canEdit && (
                            <button
                              onClick={() => handleOpenEdit(rec)}
                              title="編輯"
                              className="p-1.5 text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                          )}

                          {/* Delete */}
                          {canDelete && (
                            <button
                              onClick={() => handleDeleteRecord(rec.id, rec.moNumber)}
                              title="刪除"
                              className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        <div className="px-4 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <div>
            總共 <span className="font-semibold text-slate-700">{filteredRecords.length}</span> 筆紀錄
            {filteredRecords.length > 0 && ` (第 ${currentPage} / ${totalPages} 頁)`}
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage <= 1}
              className="p-1.5 rounded border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="px-2 font-mono">{currentPage}</span>
            <button
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage >= totalPages}
              className="p-1.5 rounded border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-40"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Modal: Create / Edit Form */}
      {isFormOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 p-4 overflow-y-auto">
          <div className="w-full max-w-lg bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
              <h3 className="font-semibold text-slate-900 text-sm">
                {editingRecord ? `修改包裝日報 (${editingRecord.moNumber})` : '新增包裝日報與入庫登錄'}
              </h3>
              <button
                onClick={() => setIsFormOpen(false)}
                className="text-slate-400 hover:text-slate-700 text-lg leading-none"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="p-6 space-y-4 text-xs">
              {editingRecord?.status === 'REJECTED' && editingRecord.reviewNotes && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-800">
                  <div className="font-bold flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" /> 主管退回意見說明:
                  </div>
                  <p className="mt-1 text-[11px]">{editingRecord.reviewNotes}</p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    日期 <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500"
                  />
                  {formErrors.date && <p className="text-rose-500 text-[10px] mt-0.5">{formErrors.date}</p>}
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    製令單號 <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.moNumber}
                    onChange={(e) => setFormData({ ...formData, moNumber: e.target.value })}
                    placeholder="例: MO-20261019-01"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500 font-mono"
                  />
                  {formErrors.moNumber && <p className="text-rose-500 text-[10px] mt-0.5">{formErrors.moNumber}</p>}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    品名 <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={formData.productName}
                    onChange={(e) => setFormData({ ...formData, productName: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500"
                  >
                    <option value="無氧銅精拉線">無氧銅精拉線</option>
                    <option value="鍍錫銅絞線">鍍錫銅絞線</option>
                    <option value="漆包絕緣銅線">漆包絕緣銅線</option>
                    <option value="磷青銅圓線">磷青銅圓線</option>
                    <option value="黃銅精密細線">黃銅精密細線</option>
                  </select>
                  {formErrors.productName && <p className="text-rose-500 text-[10px] mt-0.5">{formErrors.productName}</p>}
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    數量 (PCS/軸) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="1"
                    value={formData.quantity}
                    onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500 font-mono font-bold"
                  />
                  {formErrors.quantity && <p className="text-rose-500 text-[10px] mt-0.5">{formErrors.quantity}</p>}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    線材批號 <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.wireBatch}
                    onChange={(e) => setFormData({ ...formData, wireBatch: e.target.value })}
                    placeholder="例: LOT-CU-2610A"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500 font-mono"
                  />
                  {formErrors.wireBatch && <p className="text-rose-500 text-[10px] mt-0.5">{formErrors.wireBatch}</p>}
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    線徑 (mm) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    step="0.001"
                    min="0.01"
                    value={formData.wireGauge}
                    onChange={(e) => setFormData({ ...formData, wireGauge: parseFloat(e.target.value) || 0 })}
                    placeholder="例: 0.850"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500 font-mono"
                  />
                  {formErrors.wireGauge && <p className="text-rose-500 text-[10px] mt-0.5">{formErrors.wireGauge}</p>}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    設備編號 <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.machineId}
                    onChange={(e) => setFormData({ ...formData, machineId: e.target.value })}
                    placeholder="例: LINE-01 / DRAW-03"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500 font-mono"
                  />
                  {formErrors.machineId && <p className="text-rose-500 text-[10px] mt-0.5">{formErrors.machineId}</p>}
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    包裝人員 <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.packer}
                    onChange={(e) => setFormData({ ...formData, packer: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500"
                  />
                  {formErrors.packer && <p className="text-rose-500 text-[10px] mt-0.5">{formErrors.packer}</p>}
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">備註說明</label>
                <textarea
                  rows={2}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="可填寫外觀檢驗、包裝樣式或客戶特殊要求..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              {/* Submit option */}
              <div className="pt-2 border-t border-slate-200">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.autoSubmit}
                    onChange={(e) => setFormData({ ...formData, autoSubmit: e.target.checked })}
                    className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                  />
                  <span className="font-semibold text-slate-800">
                    {editingRecord?.status === 'REJECTED' ? '儲存並立即重新送交審核' : '儲存後直接送交主管審核'}
                  </span>
                </label>
                <p className="text-[11px] text-slate-500 mt-0.5 ml-6">
                  未勾選時將存為「草稿」，可稍後再次編輯後手動送審。
                </p>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-50 font-medium"
                >
                  取消
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 font-semibold shadow-xs disabled:opacity-50"
                >
                  {isSubmitting ? '處理中...' : '確認儲存'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import crypto from 'crypto';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;
const DATA_DIR = path.resolve(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'warehouse_db.json');

app.use(express.json({ limit: '10mb' }));

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Data structures
export interface User {
  id: string;
  username: string;
  name: string;
  role: 'admin' | 'manager' | 'operator';
  passwordHash: string; // In production/backend validation
  department: string;
  active: boolean;
  createdAt: string;
}

export type RecordStatus = 'DRAFT' | 'PENDING' | 'APPROVED' | 'REJECTED' | 'VOIDED';

export interface InboundRecord {
  id: string;
  date: string;              // YYYY-MM-DD
  moNumber: string;          // 製令單號
  productName: string;       // 品名
  quantity: number;          // 數量 (正整數)
  wireBatch: string;         // 線材批號
  wireGauge: number;         // 線徑 (mm)
  machineId: string;         // 設備編號
  packer: string;            // 包裝人員
  status: RecordStatus;      // 狀態
  notes?: string;            // 備註
  createdById: string;       // 建立者帳號 ID
  createdByName: string;     // 建立者名稱
  createdAt: string;
  updatedAt: string;
  reviewerId?: string;       // 審核主管
  reviewerName?: string;
  reviewedAt?: string;
  reviewNotes?: string;      // 審核/退回/作廢原因說明
  batchLabelGenerated?: boolean;
}

export interface OutboundRecord {
  id: string;
  date: string;              // 出貨日期 YYYY-MM-DD
  shippingOrderNo: string;   // 客戶出貨單號
  customerName: string;      // 客戶名稱
  productName: string;       // 品名
  quantity: number;          // 出貨數量
  wireBatch: string;         // 指定線材批號
  wireGauge: number;         // 線徑 (mm)
  tallyStation?: string;     // 理貨台/設備編號
  tallyPerson: string;       // 理貨人員
  status: RecordStatus;      // 狀態
  notes?: string;            // 備註
  createdById: string;
  createdByName: string;
  createdAt: string;
  updatedAt: string;
  reviewerId?: string;
  reviewerName?: string;
  reviewedAt?: string;
  reviewNotes?: string;
  stockDeducted?: boolean;   // 是否已扣庫存
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  userRole: string;
  action: string;            // CREATE, UPDATE, APPROVE, REJECT, VOID, DELETE, IMPORT, STOCK_DEDUCT
  targetType: 'INBOUND' | 'OUTBOUND' | 'USER' | 'SYSTEM';
  targetId: string;
  details: string;
}

export interface DatabaseSchema {
  users: User[];
  inboundRecords: InboundRecord[];
  outboundRecords: OutboundRecord[];
  auditLogs: AuditLog[];
}

function hashPassword(pwd: string): string {
  return crypto.createHash('sha256').update(pwd + '_salt_wms_2026').digest('hex');
}

// Initial demo database seed
function getInitialDatabase(): DatabaseSchema {
  const users: User[] = [
    {
      id: 'usr_admin',
      username: 'admin',
      name: '林管理 (Admin)',
      role: 'admin',
      passwordHash: hashPassword('admin123'),
      department: '系統資訊部',
      active: true,
      createdAt: '2026-10-01T08:00:00.000Z'
    },
    {
      id: 'usr_manager',
      username: 'manager',
      name: '張主管 (Supervisor)',
      role: 'manager',
      passwordHash: hashPassword('manager123'),
      department: '生管與倉儲部',
      active: true,
      createdAt: '2026-10-01T08:00:00.000Z'
    },
    {
      id: 'usr_operator',
      username: 'operator',
      name: '陳作業 (Operator)',
      role: 'operator',
      passwordHash: hashPassword('operator123'),
      department: '包裝理貨組',
      active: true,
      createdAt: '2026-10-01T08:00:00.000Z'
    }
  ];

  const todayStr = '2026-10-19';
  const yestStr = '2026-10-18';
  const prevStr = '2026-10-15';

  const inboundRecords: InboundRecord[] = [
    {
      id: 'INB-20261015-001',
      date: prevStr,
      moNumber: 'MO-20261015-01',
      productName: '無氧銅精拉線',
      quantity: 5000,
      wireBatch: 'LOT-CU-2610A',
      wireGauge: 0.85,
      machineId: 'LINE-03',
      packer: '陳作業 (Operator)',
      status: 'APPROVED',
      notes: '首批檢驗合格，真空防潮包裝',
      createdById: 'usr_operator',
      createdByName: '陳作業 (Operator)',
      createdAt: '2026-10-15T09:30:00.000Z',
      updatedAt: '2026-10-15T11:00:00.000Z',
      reviewerId: 'usr_manager',
      reviewerName: '張主管 (Supervisor)',
      reviewedAt: '2026-10-15T11:00:00.000Z',
      reviewNotes: '線徑抽驗合格，准予入庫'
    },
    {
      id: 'INB-20261018-002',
      date: yestStr,
      moNumber: 'MO-20261018-02',
      productName: '鍍錫銅絞線',
      quantity: 3200,
      wireBatch: 'LOT-SN-2610B',
      wireGauge: 1.20,
      machineId: 'LINE-01',
      packer: '陳作業 (Operator)',
      status: 'APPROVED',
      notes: '外銷歐盟規格，抗氧化處理',
      createdById: 'usr_operator',
      createdByName: '陳作業 (Operator)',
      createdAt: '2026-10-18T10:15:00.000Z',
      updatedAt: '2026-10-18T14:20:00.000Z',
      reviewerId: 'usr_manager',
      reviewerName: '張主管 (Supervisor)',
      reviewedAt: '2026-10-18T14:20:00.000Z',
      reviewNotes: '核對製令與檢驗報告無誤'
    },
    {
      id: 'INB-20261019-003',
      date: todayStr,
      moNumber: 'MO-20261019-03',
      productName: '漆包絕緣銅線',
      quantity: 2400,
      wireBatch: 'LOT-EN-2610C',
      wireGauge: 0.45,
      machineId: 'LINE-05',
      packer: '陳作業 (Operator)',
      status: 'PENDING',
      notes: '耐溫200度耐熱級，今日包裝完成送審',
      createdById: 'usr_operator',
      createdByName: '陳作業 (Operator)',
      createdAt: '2026-10-19T08:45:00.000Z',
      updatedAt: '2026-10-19T08:45:00.000Z'
    },
    {
      id: 'INB-20261019-004',
      date: todayStr,
      moNumber: 'MO-20261019-04',
      productName: '無氧銅精拉線',
      quantity: 1800,
      wireBatch: 'LOT-CU-2610A',
      wireGauge: 0.85,
      machineId: 'LINE-02',
      packer: '陳作業 (Operator)',
      status: 'DRAFT',
      notes: '尚未過磅完成，先暫存草稿',
      createdById: 'usr_operator',
      createdByName: '陳作業 (Operator)',
      createdAt: '2026-10-19T10:00:00.000Z',
      updatedAt: '2026-10-19T10:00:00.000Z'
    }
  ];

  const outboundRecords: OutboundRecord[] = [
    {
      id: 'OUT-20261018-001',
      date: yestStr,
      shippingOrderNo: 'SO-20261018-T01',
      customerName: '台灣電工精密股份有限公司',
      productName: '無氧銅精拉線',
      quantity: 2000,
      wireBatch: 'LOT-CU-2610A',
      wireGauge: 0.85,
      tallyStation: 'TALLY-BAY-1',
      tallyPerson: '陳作業 (Operator)',
      status: 'APPROVED',
      notes: '客戶要求貼附專用QR Code出貨標籤',
      createdById: 'usr_operator',
      createdByName: '陳作業 (Operator)',
      createdAt: '2026-10-18T13:00:00.000Z',
      updatedAt: '2026-10-18T15:30:00.000Z',
      reviewerId: 'usr_manager',
      reviewerName: '張主管 (Supervisor)',
      reviewedAt: '2026-10-18T15:30:00.000Z',
      reviewNotes: '理貨點驗完畢，已核准扣帳並出貨',
      stockDeducted: true
    },
    {
      id: 'OUT-20261019-002',
      date: todayStr,
      shippingOrderNo: 'SO-20261019-T02',
      customerName: '啟碁電子科技',
      productName: '鍍錫銅絞線',
      quantity: 1000,
      wireBatch: 'LOT-SN-2610B',
      wireGauge: 1.20,
      tallyStation: 'TALLY-BAY-2',
      tallyPerson: '陳作業 (Operator)',
      status: 'PENDING',
      notes: '依客戶出貨單匯入，待主管覆核扣帳',
      createdById: 'usr_operator',
      createdByName: '陳作業 (Operator)',
      createdAt: '2026-10-19T09:10:00.000Z',
      updatedAt: '2026-10-19T09:10:00.000Z',
      stockDeducted: false
    }
  ];

  const auditLogs: AuditLog[] = [
    {
      id: 'LOG-001',
      timestamp: '2026-10-15T11:00:00.000Z',
      userId: 'usr_manager',
      userName: '張主管 (Supervisor)',
      userRole: 'manager',
      action: 'APPROVE',
      targetType: 'INBOUND',
      targetId: 'INB-20261015-001',
      details: '審核通過入庫單 INB-20261015-001，數量 5000 入庫成功'
    },
    {
      id: 'LOG-002',
      timestamp: '2026-10-18T15:30:00.000Z',
      userId: 'usr_manager',
      userName: '張主管 (Supervisor)',
      userRole: 'manager',
      action: 'STOCK_DEDUCT',
      targetType: 'OUTBOUND',
      targetId: 'OUT-20261018-001',
      details: '審核通過出貨單 OUT-20261018-001，扣除庫存數量 2000'
    }
  ];

  return { users, inboundRecords, outboundRecords, auditLogs };
}

// Read database
function readDB(): DatabaseSchema {
  try {
    if (!fs.existsSync(DB_FILE)) {
      const initial = getInitialDatabase();
      writeDB(initial);
      return initial;
    }
    const data = fs.readFileSync(DB_FILE, 'utf-8');
    return JSON.parse(data);
  } catch (err) {
    console.error('Error reading database file, resetting to initial seed:', err);
    const initial = getInitialDatabase();
    writeDB(initial);
    return initial;
  }
}

// Write database atomically
function writeDB(data: DatabaseSchema): void {
  const tempFile = `${DB_FILE}.${Date.now()}.tmp`;
  fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), 'utf-8');
  fs.renameSync(tempFile, DB_FILE);
}

// Session store in memory
const sessionStore = new Map<string, { userId: string; expiresAt: number }>();

function generateToken(userId: string): string {
  const token = crypto.randomBytes(32).toString('hex');
  sessionStore.set(token, {
    userId,
    expiresAt: Date.now() + 24 * 60 * 60 * 1000 // 24 hours
  });
  return token;
}

function authMiddleware(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: '未登入或缺少認證權杖' });
  }
  const token = authHeader.substring(7);
  const session = sessionStore.get(token);
  if (!session || session.expiresAt < Date.now()) {
    sessionStore.delete(token);
    return res.status(401).json({ error: '登入已逾期，請重新登入' });
  }

  const db = readDB();
  const user = db.users.find(u => u.id === session.userId && u.active);
  if (!user) {
    return res.status(401).json({ error: '無效的使用者帳號' });
  }

  (req as any).user = user;
  next();
}

// -------------------------------------------------------------
// Authentication Endpoints
// -------------------------------------------------------------

app.post('/api/auth/login', (req: Request, res: Response) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: '請輸入帳號與密碼' });
  }

  const db = readDB();
  const user = db.users.find(u => u.username.toLowerCase() === username.trim().toLowerCase());
  if (!user || !user.active) {
    return res.status(401).json({ error: '帳號不存在或已停用' });
  }

  const hashed = hashPassword(password);
  if (user.passwordHash !== hashed) {
    return res.status(401).json({ error: '密碼錯誤，請重新確認' });
  }

  const token = generateToken(user.id);
  const { passwordHash: _, ...userWithoutPwd } = user;
  res.json({ token, user: userWithoutPwd });
});

app.get('/api/auth/me', authMiddleware, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  const { passwordHash: _, ...userWithoutPwd } = user;
  res.json({ user: userWithoutPwd });
});

app.post('/api/auth/logout', authMiddleware, (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7);
    sessionStore.delete(token);
  }
  res.json({ success: true, message: '已成功登出' });
});

// -------------------------------------------------------------
// Inventory Calculation Helper
// -------------------------------------------------------------
function calculateInventory(db: DatabaseSchema) {
  // Group inventory by productName + wireBatch + wireGauge
  const inventoryMap = new Map<string, {
    key: string;
    productName: string;
    wireBatch: string;
    wireGauge: number;
    inboundQty: number;
    outboundQty: number;
    currentStock: number;
    lastUpdated: string;
  }>();

  // Add approved inbound records
  for (const record of db.inboundRecords) {
    if (record.status === 'APPROVED') {
      const key = `${record.productName}___${record.wireBatch}___${record.wireGauge}`;
      const existing = inventoryMap.get(key) || {
        key,
        productName: record.productName,
        wireBatch: record.wireBatch,
        wireGauge: record.wireGauge,
        inboundQty: 0,
        outboundQty: 0,
        currentStock: 0,
        lastUpdated: record.updatedAt || record.createdAt
      };
      existing.inboundQty += record.quantity;
      existing.currentStock += record.quantity;
      if (new Date(record.updatedAt || record.createdAt) > new Date(existing.lastUpdated)) {
        existing.lastUpdated = record.updatedAt || record.createdAt;
      }
      inventoryMap.set(key, existing);
    }
  }

  // Deduct approved outbound records
  for (const record of db.outboundRecords) {
    if (record.status === 'APPROVED') {
      const key = `${record.productName}___${record.wireBatch}___${record.wireGauge}`;
      const existing = inventoryMap.get(key) || {
        key,
        productName: record.productName,
        wireBatch: record.wireBatch,
        wireGauge: record.wireGauge,
        inboundQty: 0,
        outboundQty: 0,
        currentStock: 0,
        lastUpdated: record.updatedAt || record.createdAt
      };
      existing.outboundQty += record.quantity;
      existing.currentStock -= record.quantity;
      if (new Date(record.updatedAt || record.createdAt) > new Date(existing.lastUpdated)) {
        existing.lastUpdated = record.updatedAt || record.createdAt;
      }
      inventoryMap.set(key, existing);
    }
  }

  return Array.from(inventoryMap.values()).sort((a, b) => a.productName.localeCompare(b.productName));
}

// -------------------------------------------------------------
// Inventory API Endpoints
// -------------------------------------------------------------
app.get('/api/inventory', authMiddleware, (_req: Request, res: Response) => {
  const db = readDB();
  const summary = calculateInventory(db);
  res.json({ inventory: summary });
});

app.get('/api/inventory/transactions', authMiddleware, (_req: Request, res: Response) => {
  const db = readDB();
  const transactions: any[] = [];

  for (const inb of db.inboundRecords) {
    if (inb.status === 'APPROVED') {
      transactions.push({
        id: inb.id,
        type: 'INBOUND',
        date: inb.date,
        docNo: inb.moNumber,
        productName: inb.productName,
        wireBatch: inb.wireBatch,
        wireGauge: inb.wireGauge,
        quantity: inb.quantity,
        targetOrSource: inb.machineId,
        person: inb.packer,
        timestamp: inb.reviewedAt || inb.updatedAt
      });
    }
  }

  for (const outb of db.outboundRecords) {
    if (outb.status === 'APPROVED') {
      transactions.push({
        id: outb.id,
        type: 'OUTBOUND',
        date: outb.date,
        docNo: outb.shippingOrderNo,
        productName: outb.productName,
        wireBatch: outb.wireBatch,
        wireGauge: outb.wireGauge,
        quantity: -outb.quantity,
        targetOrSource: outb.customerName,
        person: outb.tallyPerson,
        timestamp: outb.reviewedAt || outb.updatedAt
      });
    }
  }

  transactions.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  res.json({ transactions });
});

// -------------------------------------------------------------
// Inbound Records Endpoints (包裝日報與入庫)
// -------------------------------------------------------------

// Validation helper
function validateInboundData(data: Partial<InboundRecord>): string | null {
  if (!data.date || !/^\d{4}-\d{2}-\d{2}$/.test(data.date)) {
    return '日期為必填項目，且必須為 YYYY-MM-DD 格式';
  }
  if (!data.moNumber || data.moNumber.trim().length === 0) {
    return '製令單號為必填項目';
  }
  if (!data.productName || data.productName.trim().length === 0) {
    return '品名為必填項目';
  }
  if (!data.quantity || typeof data.quantity !== 'number' || data.quantity <= 0 || !Number.isInteger(data.quantity)) {
    return '數量必須為大於 0 的正整數';
  }
  if (!data.wireBatch || data.wireBatch.trim().length === 0) {
    return '線材批號為必填項目';
  }
  if (data.wireGauge === undefined || typeof data.wireGauge !== 'number' || data.wireGauge <= 0) {
    return '線徑必須為大於 0 的有效數值 (mm)';
  }
  if (!data.machineId || data.machineId.trim().length === 0) {
    return '設備編號為必填項目';
  }
  if (!data.packer || data.packer.trim().length === 0) {
    return '包裝人員為必填項目';
  }
  return null;
}

app.get('/api/inbound', authMiddleware, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  const { search, status, startDate, endDate, myOnly } = req.query;

  const db = readDB();
  let list = [...db.inboundRecords];

  // Operator permission rule: if myOnly is set or if operator can only view their own
  if (user.role === 'operator' && myOnly === 'true') {
    list = list.filter(r => r.createdById === user.id);
  }

  if (search) {
    const q = (search as string).toLowerCase().trim();
    list = list.filter(r =>
      r.moNumber.toLowerCase().includes(q) ||
      r.productName.toLowerCase().includes(q) ||
      r.wireBatch.toLowerCase().includes(q) ||
      r.machineId.toLowerCase().includes(q) ||
      r.packer.toLowerCase().includes(q)
    );
  }

  if (status && status !== 'ALL') {
    list = list.filter(r => r.status === status);
  }

  if (startDate) {
    list = list.filter(r => r.date >= (startDate as string));
  }

  if (endDate) {
    list = list.filter(r => r.date <= (endDate as string));
  }

  list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  res.json({ records: list });
});

app.post('/api/inbound', authMiddleware, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  const error = validateInboundData(req.body);
  if (error) {
    return res.status(400).json({ error });
  }

  const { date, moNumber, productName, quantity, wireBatch, wireGauge, machineId, packer, notes, autoSubmit } = req.body;
  const now = new Date().toISOString();
  const id = `INB-${date.replace(/-/g, '')}-${Math.floor(100 + Math.random() * 900)}`;

  const newRecord: InboundRecord = {
    id,
    date,
    moNumber: moNumber.trim(),
    productName: productName.trim(),
    quantity: Math.floor(quantity),
    wireBatch: wireBatch.trim(),
    wireGauge: Number(Number(wireGauge).toFixed(3)),
    machineId: machineId.trim(),
    packer: packer.trim(),
    status: autoSubmit ? 'PENDING' : 'DRAFT',
    notes: notes ? notes.trim() : '',
    createdById: user.id,
    createdByName: user.name,
    createdAt: now,
    updatedAt: now,
    batchLabelGenerated: true
  };

  const db = readDB();
  db.inboundRecords.push(newRecord);

  // Add audit log
  db.auditLogs.push({
    id: `LOG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    timestamp: now,
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    action: autoSubmit ? 'SUBMIT' : 'CREATE',
    targetType: 'INBOUND',
    targetId: id,
    details: `建立包裝日報/入庫單 ${moNumber}，品名: ${productName}，數量: ${quantity}`
  });

  writeDB(db);
  res.status(201).json({ record: newRecord, message: autoSubmit ? '已成功建立並送交主管審核' : '已成功儲存草稿' });
});

app.put('/api/inbound/:id', authMiddleware, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  const { id } = req.params;
  const db = readDB();
  const recordIndex = db.inboundRecords.findIndex(r => r.id === id);

  if (recordIndex === -1) {
    return res.status(404).json({ error: '找不到該筆入庫紀錄' });
  }

  const existing = db.inboundRecords[recordIndex];

  // Permission check: Operators can only edit their own draft or rejected records
  if (user.role === 'operator') {
    if (existing.createdById !== user.id) {
      return res.status(403).json({ error: '權限不足：您只能修改自己填報的紀錄' });
    }
    if (existing.status !== 'DRAFT' && existing.status !== 'REJECTED') {
      return res.status(403).json({ error: '已送審、已核准或已作廢的紀錄無法直接編輯' });
    }
  }

  const validationError = validateInboundData(req.body);
  if (validationError) {
    return res.status(400).json({ error: validationError });
  }

  const { date, moNumber, productName, quantity, wireBatch, wireGauge, machineId, packer, notes, resubmit } = req.body;
  const now = new Date().toISOString();

  let nextStatus = existing.status;
  if (resubmit) {
    nextStatus = 'PENDING';
  } else if (existing.status === 'REJECTED') {
    nextStatus = 'DRAFT';
  }

  const updatedRecord: InboundRecord = {
    ...existing,
    date,
    moNumber: moNumber.trim(),
    productName: productName.trim(),
    quantity: Math.floor(quantity),
    wireBatch: wireBatch.trim(),
    wireGauge: Number(Number(wireGauge).toFixed(3)),
    machineId: machineId.trim(),
    packer: packer.trim(),
    notes: notes ? notes.trim() : '',
    status: nextStatus,
    updatedAt: now
  };

  db.inboundRecords[recordIndex] = updatedRecord;

  db.auditLogs.push({
    id: `LOG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    timestamp: now,
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    action: resubmit ? 'RESUBMIT' : 'UPDATE',
    targetType: 'INBOUND',
    targetId: id,
    details: `修改入庫單 ${moNumber}${resubmit ? ' 並重新送交審核' : ''}`
  });

  writeDB(db);
  res.json({ record: updatedRecord, message: resubmit ? '已成功修改並重新送審' : '資料修改成功' });
});

// Action endpoint: submit, approve, reject, void, resubmit
app.post('/api/inbound/:id/action', authMiddleware, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  const { id } = req.params;
  const { action, reviewNotes } = req.body; // action: 'SUBMIT' | 'APPROVE' | 'REJECT' | 'VOID' | 'RESUBMIT'

  if (!action) {
    return res.status(400).json({ error: '缺少操作指令' });
  }

  const db = readDB();
  const record = db.inboundRecords.find(r => r.id === id);
  if (!record) {
    return res.status(404).json({ error: '找不到該筆入庫紀錄' });
  }

  const now = new Date().toISOString();

  if (action === 'SUBMIT') {
    if (record.status !== 'DRAFT') {
      return res.status(400).json({ error: '只有草稿狀態才能送交審核' });
    }
    record.status = 'PENDING';
    record.updatedAt = now;
  } else if (action === 'RESUBMIT') {
    if (record.status !== 'REJECTED') {
      return res.status(400).json({ error: '只有被退回的紀錄才能重新送審' });
    }
    record.status = 'PENDING';
    record.updatedAt = now;
  } else if (action === 'APPROVE') {
    // Only manager or admin can approve
    if (user.role !== 'manager' && user.role !== 'admin') {
      return res.status(403).json({ error: '權限不足：只有主管或管理員可以審核' });
    }
    if (record.status !== 'PENDING') {
      return res.status(400).json({ error: '該單據不在待審核狀態' });
    }
    record.status = 'APPROVED';
    record.reviewerId = user.id;
    record.reviewerName = user.name;
    record.reviewedAt = now;
    record.reviewNotes = reviewNotes || '主管審核通過，庫存已正式入帳';
    record.updatedAt = now;
  } else if (action === 'REJECT') {
    if (user.role !== 'manager' && user.role !== 'admin') {
      return res.status(403).json({ error: '權限不足：只有主管或管理員可以執行退回' });
    }
    if (record.status !== 'PENDING') {
      return res.status(400).json({ error: '該單據不在待審核狀態' });
    }
    if (!reviewNotes || reviewNotes.trim().length === 0) {
      return res.status(400).json({ error: '退回時必須填寫退回原因說明，以供現場人員修改' });
    }
    record.status = 'REJECTED';
    record.reviewerId = user.id;
    record.reviewerName = user.name;
    record.reviewedAt = now;
    record.reviewNotes = reviewNotes.trim();
    record.updatedAt = now;
  } else if (action === 'VOID') {
    if (user.role !== 'manager' && user.role !== 'admin') {
      return res.status(403).json({ error: '權限不足：只有主管或管理員可以作廢單據' });
    }
    if (!reviewNotes || reviewNotes.trim().length === 0) {
      return res.status(400).json({ error: '作廢單據必須填寫作廢原因' });
    }
    record.status = 'VOIDED';
    record.reviewerId = user.id;
    record.reviewerName = user.name;
    record.reviewedAt = now;
    record.reviewNotes = reviewNotes.trim();
    record.updatedAt = now;
  } else {
    return res.status(400).json({ error: '不支援的操作類型' });
  }

  // Audit log
  db.auditLogs.push({
    id: `LOG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    timestamp: now,
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    action,
    targetType: 'INBOUND',
    targetId: id,
    details: `入庫單 ${record.moNumber} 狀態變更為 ${record.status}。備註: ${reviewNotes || '無'}`
  });

  writeDB(db);
  res.json({ record, message: `操作完成：狀態已更新為「${record.status}」` });
});

app.delete('/api/inbound/:id', authMiddleware, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  const { id } = req.params;
  const db = readDB();
  const index = db.inboundRecords.findIndex(r => r.id === id);

  if (index === -1) {
    return res.status(404).json({ error: '找不到該筆入庫紀錄' });
  }

  const record = db.inboundRecords[index];

  // Only admin or the creator of DRAFT record can delete
  if (user.role !== 'admin') {
    if (record.status !== 'DRAFT') {
      return res.status(403).json({ error: '只有管理員可以刪除非草稿紀錄，一般使用者請使用作廢流程或僅可刪除草稿' });
    }
    if (record.createdById !== user.id) {
      return res.status(403).json({ error: '權限不足：無法刪除他人的草稿' });
    }
  }

  db.inboundRecords.splice(index, 1);
  const now = new Date().toISOString();

  db.auditLogs.push({
    id: `LOG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    timestamp: now,
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    action: 'DELETE',
    targetType: 'INBOUND',
    targetId: id,
    details: `刪除入庫紀錄 ${record.moNumber} (${record.productName})`
  });

  writeDB(db);
  res.json({ success: true, message: '紀錄已成功刪除' });
});

// -------------------------------------------------------------
// Outbound & Picking Endpoints (理貨與出貨扣帳)
// -------------------------------------------------------------

function validateOutboundData(data: Partial<OutboundRecord>): string | null {
  if (!data.date || !/^\d{4}-\d{2}-\d{2}$/.test(data.date)) {
    return '出貨日期為必填項目，且必須為 YYYY-MM-DD 格式';
  }
  if (!data.shippingOrderNo || data.shippingOrderNo.trim().length === 0) {
    return '客戶出貨單號為必填項目';
  }
  if (!data.customerName || data.customerName.trim().length === 0) {
    return '客戶名稱為必填項目';
  }
  if (!data.productName || data.productName.trim().length === 0) {
    return '品名為必填項目';
  }
  if (!data.quantity || typeof data.quantity !== 'number' || data.quantity <= 0 || !Number.isInteger(data.quantity)) {
    return '出貨數量必須為大於 0 的正整數';
  }
  if (!data.wireBatch || data.wireBatch.trim().length === 0) {
    return '指定線材批號為必填項目';
  }
  if (data.wireGauge === undefined || typeof data.wireGauge !== 'number' || data.wireGauge <= 0) {
    return '線徑必須為大於 0 的有效數值 (mm)';
  }
  if (!data.tallyPerson || data.tallyPerson.trim().length === 0) {
    return '理貨人員為必填項目';
  }
  return null;
}

app.get('/api/outbound', authMiddleware, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  const { search, status, startDate, endDate, myOnly } = req.query;

  const db = readDB();
  let list = [...db.outboundRecords];

  if (user.role === 'operator' && myOnly === 'true') {
    list = list.filter(r => r.createdById === user.id);
  }

  if (search) {
    const q = (search as string).toLowerCase().trim();
    list = list.filter(r =>
      r.shippingOrderNo.toLowerCase().includes(q) ||
      r.customerName.toLowerCase().includes(q) ||
      r.productName.toLowerCase().includes(q) ||
      r.wireBatch.toLowerCase().includes(q) ||
      r.tallyPerson.toLowerCase().includes(q)
    );
  }

  if (status && status !== 'ALL') {
    list = list.filter(r => r.status === status);
  }

  if (startDate) {
    list = list.filter(r => r.date >= (startDate as string));
  }

  if (endDate) {
    list = list.filter(r => r.date <= (endDate as string));
  }

  list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  res.json({ records: list });
});

app.post('/api/outbound', authMiddleware, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  const error = validateOutboundData(req.body);
  if (error) {
    return res.status(400).json({ error });
  }

  const { date, shippingOrderNo, customerName, productName, quantity, wireBatch, wireGauge, tallyStation, tallyPerson, notes, autoSubmit } = req.body;
  const now = new Date().toISOString();
  const id = `OUT-${date.replace(/-/g, '')}-${Math.floor(100 + Math.random() * 900)}`;

  const newRecord: OutboundRecord = {
    id,
    date,
    shippingOrderNo: shippingOrderNo.trim(),
    customerName: customerName.trim(),
    productName: productName.trim(),
    quantity: Math.floor(quantity),
    wireBatch: wireBatch.trim(),
    wireGauge: Number(Number(wireGauge).toFixed(3)),
    tallyStation: tallyStation ? tallyStation.trim() : '理貨區-A',
    tallyPerson: tallyPerson.trim(),
    status: autoSubmit ? 'PENDING' : 'DRAFT',
    notes: notes ? notes.trim() : '',
    createdById: user.id,
    createdByName: user.name,
    createdAt: now,
    updatedAt: now,
    stockDeducted: false
  };

  const db = readDB();
  db.outboundRecords.push(newRecord);

  db.auditLogs.push({
    id: `LOG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    timestamp: now,
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    action: autoSubmit ? 'SUBMIT' : 'CREATE',
    targetType: 'OUTBOUND',
    targetId: id,
    details: `建立理貨出貨單 ${shippingOrderNo} (${customerName})，數量: ${quantity}`
  });

  writeDB(db);
  res.status(201).json({ record: newRecord, message: autoSubmit ? '理貨單已建立並送交主管審核出貨扣帳' : '已儲存理貨單草稿' });
});

// Batch import from customer shipping orders
app.post('/api/outbound/import', authMiddleware, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  const { orders } = req.body;

  if (!orders || !Array.isArray(orders) || orders.length === 0) {
    return res.status(400).json({ error: '匯入資料不得為空' });
  }

  const db = readDB();
  const importedRecords: OutboundRecord[] = [];
  const errors: string[] = [];
  const now = new Date().toISOString();

  orders.forEach((item, index) => {
    const rowNum = index + 1;
    const err = validateOutboundData(item);
    if (err) {
      errors.push(`第 ${rowNum} 筆 (單號 ${item.shippingOrderNo || '未知'}): ${err}`);
      return;
    }

    const id = `OUT-${item.date.replace(/-/g, '')}-${Math.floor(100 + Math.random() * 900)}${index}`;
    const rec: OutboundRecord = {
      id,
      date: item.date,
      shippingOrderNo: item.shippingOrderNo.trim(),
      customerName: item.customerName.trim(),
      productName: item.productName.trim(),
      quantity: Math.floor(item.quantity),
      wireBatch: item.wireBatch.trim(),
      wireGauge: Number(Number(item.wireGauge).toFixed(3)),
      tallyStation: item.tallyStation ? item.tallyStation.trim() : '匯入自動分配',
      tallyPerson: item.tallyPerson ? item.tallyPerson.trim() : user.name,
      status: 'PENDING', // Customer imported orders are immediately placed into pending review & stock deduction
      notes: item.notes ? item.notes.trim() : '由客戶出貨系統單據批次匯入',
      createdById: user.id,
      createdByName: user.name,
      createdAt: now,
      updatedAt: now,
      stockDeducted: false
    };

    importedRecords.push(rec);
  });

  if (importedRecords.length === 0) {
    return res.status(400).json({ error: '匯入失敗，所有資料均未通過驗證', errors });
  }

  db.outboundRecords.push(...importedRecords);

  db.auditLogs.push({
    id: `LOG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    timestamp: now,
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    action: 'IMPORT',
    targetType: 'OUTBOUND',
    targetId: `BATCH-${importedRecords.length}`,
    details: `從客戶出貨單系統批次匯入 ${importedRecords.length} 筆理貨資料`
  });

  writeDB(db);
  res.status(201).json({
    success: true,
    count: importedRecords.length,
    importedRecords,
    errors: errors.length > 0 ? errors : undefined,
    message: `成功匯入 ${importedRecords.length} 筆客戶出貨明細${errors.length > 0 ? ` (略過 ${errors.length} 筆未符規範資料)` : ''}`
  });
});

app.put('/api/outbound/:id', authMiddleware, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  const { id } = req.params;
  const db = readDB();
  const index = db.outboundRecords.findIndex(r => r.id === id);

  if (index === -1) {
    return res.status(404).json({ error: '找不到該筆出貨理貨紀錄' });
  }

  const existing = db.outboundRecords[index];

  if (user.role === 'operator') {
    if (existing.createdById !== user.id) {
      return res.status(403).json({ error: '權限不足：您只能修改自己建立的理貨單' });
    }
    if (existing.status !== 'DRAFT' && existing.status !== 'REJECTED') {
      return res.status(403).json({ error: '已送審、已核准或已作廢的理貨單無法直接編輯' });
    }
  }

  const validationError = validateOutboundData(req.body);
  if (validationError) {
    return res.status(400).json({ error: validationError });
  }

  const { date, shippingOrderNo, customerName, productName, quantity, wireBatch, wireGauge, tallyStation, tallyPerson, notes, resubmit } = req.body;
  const now = new Date().toISOString();

  let nextStatus = existing.status;
  if (resubmit) {
    nextStatus = 'PENDING';
  } else if (existing.status === 'REJECTED') {
    nextStatus = 'DRAFT';
  }

  const updatedRecord: OutboundRecord = {
    ...existing,
    date,
    shippingOrderNo: shippingOrderNo.trim(),
    customerName: customerName.trim(),
    productName: productName.trim(),
    quantity: Math.floor(quantity),
    wireBatch: wireBatch.trim(),
    wireGauge: Number(Number(wireGauge).toFixed(3)),
    tallyStation: tallyStation ? tallyStation.trim() : existing.tallyStation,
    tallyPerson: tallyPerson.trim(),
    notes: notes ? notes.trim() : '',
    status: nextStatus,
    updatedAt: now
  };

  db.outboundRecords[index] = updatedRecord;

  db.auditLogs.push({
    id: `LOG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    timestamp: now,
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    action: resubmit ? 'RESUBMIT' : 'UPDATE',
    targetType: 'OUTBOUND',
    targetId: id,
    details: `修改出貨理貨單 ${shippingOrderNo}${resubmit ? ' 並重新送交審核' : ''}`
  });

  writeDB(db);
  res.json({ record: updatedRecord, message: resubmit ? '理貨單已更新並重新送審' : '理貨單修改成功' });
});

app.post('/api/outbound/:id/action', authMiddleware, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  const { id } = req.params;
  const { action, reviewNotes } = req.body;

  if (!action) {
    return res.status(400).json({ error: '缺少操作指令' });
  }

  const db = readDB();
  const record = db.outboundRecords.find(r => r.id === id);
  if (!record) {
    return res.status(404).json({ error: '找不到該筆出貨理貨紀錄' });
  }

  const now = new Date().toISOString();

  if (action === 'SUBMIT') {
    if (record.status !== 'DRAFT') {
      return res.status(400).json({ error: '只有草稿狀態才能送交審核' });
    }
    record.status = 'PENDING';
    record.updatedAt = now;
  } else if (action === 'RESUBMIT') {
    if (record.status !== 'REJECTED') {
      return res.status(400).json({ error: '只有被退回的紀錄才能重新送審' });
    }
    record.status = 'PENDING';
    record.updatedAt = now;
  } else if (action === 'APPROVE') {
    if (user.role !== 'manager' && user.role !== 'admin') {
      return res.status(403).json({ error: '權限不足：只有主管或管理員可以審核出貨' });
    }
    if (record.status !== 'PENDING') {
      return res.status(400).json({ error: '該單據不在待審核狀態' });
    }

    // Check available stock before approving & deducting!
    const inventory = calculateInventory(db);
    const key = `${record.productName}___${record.wireBatch}___${record.wireGauge}`;
    const stockItem = inventory.find(i => i.key === key);
    const currentStock = stockItem ? stockItem.currentStock : 0;

    if (currentStock < record.quantity) {
      return res.status(400).json({
        error: `庫存不足無法出貨扣帳！目前【${record.productName} (批號:${record.wireBatch}, 線徑:${record.wireGauge}mm)】在庫數量僅 ${currentStock}，需求出貨數量為 ${record.quantity}。`
      });
    }

    record.status = 'APPROVED';
    record.reviewerId = user.id;
    record.reviewerName = user.name;
    record.reviewedAt = now;
    record.reviewNotes = reviewNotes || '理貨無誤，主管審核核准並完成庫存自動扣帳';
    record.stockDeducted = true;
    record.updatedAt = now;
  } else if (action === 'REJECT') {
    if (user.role !== 'manager' && user.role !== 'admin') {
      return res.status(403).json({ error: '權限不足：只有主管或管理員可以退回理貨單' });
    }
    if (record.status !== 'PENDING') {
      return res.status(400).json({ error: '該單據不在待審核狀態' });
    }
    if (!reviewNotes || reviewNotes.trim().length === 0) {
      return res.status(400).json({ error: '退回時必須填寫退回原因說明' });
    }
    record.status = 'REJECTED';
    record.reviewerId = user.id;
    record.reviewerName = user.name;
    record.reviewedAt = now;
    record.reviewNotes = reviewNotes.trim();
    record.stockDeducted = false;
    record.updatedAt = now;
  } else if (action === 'VOID') {
    if (user.role !== 'manager' && user.role !== 'admin') {
      return res.status(403).json({ error: '權限不足：只有主管或管理員可以作廢理貨單' });
    }
    if (!reviewNotes || reviewNotes.trim().length === 0) {
      return res.status(400).json({ error: '作廢單據必須填寫作廢原因' });
    }
    record.status = 'VOIDED';
    record.reviewerId = user.id;
    record.reviewerName = user.name;
    record.reviewedAt = now;
    record.reviewNotes = reviewNotes.trim();
    record.stockDeducted = false;
    record.updatedAt = now;
  } else {
    return res.status(400).json({ error: '不支援的操作類型' });
  }

  db.auditLogs.push({
    id: `LOG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    timestamp: now,
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    action: action === 'APPROVE' ? 'STOCK_DEDUCT' : action,
    targetType: 'OUTBOUND',
    targetId: id,
    details: `出貨單 ${record.shippingOrderNo} (${record.customerName}) 狀態變更為 ${record.status}。${action === 'APPROVE' ? '已完成庫存扣帳。' : ''} 說明: ${reviewNotes || '無'}`
  });

  writeDB(db);
  res.json({ record, message: `操作完成：出貨單狀態更新為「${record.status}」${action === 'APPROVE' ? '，庫存已成功扣帳' : ''}` });
});

app.delete('/api/outbound/:id', authMiddleware, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  const { id } = req.params;
  const db = readDB();
  const index = db.outboundRecords.findIndex(r => r.id === id);

  if (index === -1) {
    return res.status(404).json({ error: '找不到該筆出貨理貨紀錄' });
  }

  const record = db.outboundRecords[index];

  if (user.role !== 'admin') {
    if (record.status !== 'DRAFT') {
      return res.status(403).json({ error: '只有管理員可以刪除非草稿紀錄，一般使用者請使用作廢流程或僅可刪除草稿' });
    }
    if (record.createdById !== user.id) {
      return res.status(403).json({ error: '權限不足：無法刪除他人的草稿' });
    }
  }

  db.outboundRecords.splice(index, 1);
  const now = new Date().toISOString();

  db.auditLogs.push({
    id: `LOG-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    timestamp: now,
    userId: user.id,
    userName: user.name,
    userRole: user.role,
    action: 'DELETE',
    targetType: 'OUTBOUND',
    targetId: id,
    details: `刪除出貨單 ${record.shippingOrderNo} (${record.customerName})`
  });

  writeDB(db);
  res.json({ success: true, message: '出貨理貨紀錄已成功刪除' });
});

// -------------------------------------------------------------
// Monthly Statistics & Reports API
// -------------------------------------------------------------
app.get('/api/reports/monthly', authMiddleware, (req: Request, res: Response) => {
  const { month } = req.query; // YYYY-MM
  const currentMonthStr = month ? (month as string) : new Date().toISOString().substring(0, 7);

  const db = readDB();

  // Filter approved records for that month
  const monthlyInbound = db.inboundRecords.filter(r => r.date.startsWith(currentMonthStr) && r.status === 'APPROVED');
  const monthlyOutbound = db.outboundRecords.filter(r => r.date.startsWith(currentMonthStr) && r.status === 'APPROVED');

  const totalInboundQty = monthlyInbound.reduce((sum, r) => sum + r.quantity, 0);
  const totalOutboundQty = monthlyOutbound.reduce((sum, r) => sum + r.quantity, 0);

  // Group by product name
  const productStatsMap = new Map<string, { productName: string; inboundQty: number; outboundQty: number }>();

  for (const r of monthlyInbound) {
    const stat = productStatsMap.get(r.productName) || { productName: r.productName, inboundQty: 0, outboundQty: 0 };
    stat.inboundQty += r.quantity;
    productStatsMap.set(r.productName, stat);
  }

  for (const r of monthlyOutbound) {
    const stat = productStatsMap.get(r.productName) || { productName: r.productName, inboundQty: 0, outboundQty: 0 };
    stat.outboundQty += r.quantity;
    productStatsMap.set(r.productName, stat);
  }

  // Group by day of month
  const daysInMonthMap = new Map<string, { date: string; inboundQty: number; outboundQty: number }>();
  for (const r of monthlyInbound) {
    const dayStat = daysInMonthMap.get(r.date) || { date: r.date, inboundQty: 0, outboundQty: 0 };
    dayStat.inboundQty += r.quantity;
    daysInMonthMap.set(r.date, dayStat);
  }
  for (const r of monthlyOutbound) {
    const dayStat = daysInMonthMap.get(r.date) || { date: r.date, inboundQty: 0, outboundQty: 0 };
    dayStat.outboundQty += r.quantity;
    daysInMonthMap.set(r.date, dayStat);
  }

  const dailyTrend = Array.from(daysInMonthMap.values()).sort((a, b) => a.date.localeCompare(b.date));

  res.json({
    month: currentMonthStr,
    totalInboundQty,
    totalOutboundQty,
    netChange: totalInboundQty - totalOutboundQty,
    inboundRecordCount: monthlyInbound.length,
    outboundRecordCount: monthlyOutbound.length,
    productBreakdown: Array.from(productStatsMap.values()),
    dailyTrend
  });
});

// -------------------------------------------------------------
// Audit Logs & System Management
// -------------------------------------------------------------
app.get('/api/audit-logs', authMiddleware, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  if (user.role !== 'admin' && user.role !== 'manager') {
    return res.status(403).json({ error: '權限不足：只有主管或管理員可查閱稽核日誌' });
  }

  const db = readDB();
  const sorted = [...db.auditLogs].sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  res.json({ logs: sorted.slice(0, 100) });
});

// User management (admin only)
app.get('/api/users', authMiddleware, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  if (user.role !== 'admin') {
    return res.status(403).json({ error: '權限不足：只有系統管理員可管理使用者帳號' });
  }

  const db = readDB();
  const safeUsers = db.users.map(({ passwordHash: _, ...u }) => u);
  res.json({ users: safeUsers });
});

app.post('/api/users', authMiddleware, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  if (user.role !== 'admin') {
    return res.status(403).json({ error: '權限不足：只有系統管理員可新增使用者' });
  }

  const { username, name, role, password, department } = req.body;
  if (!username || !name || !role || !password) {
    return res.status(400).json({ error: '帳號、姓名、角色與密碼皆為必填' });
  }

  const db = readDB();
  if (db.users.some(u => u.username.toLowerCase() === username.trim().toLowerCase())) {
    return res.status(400).json({ error: '該使用者帳號已存在' });
  }

  const newUser: User = {
    id: `usr_${Date.now()}`,
    username: username.trim(),
    name: name.trim(),
    role,
    passwordHash: hashPassword(password),
    department: department ? department.trim() : '現場製造部',
    active: true,
    createdAt: new Date().toISOString()
  };

  db.users.push(newUser);
  writeDB(db);

  const { passwordHash: _, ...safeUser } = newUser;
  res.status(201).json({ user: safeUser, message: '使用者帳號已成功建立' });
});

// Reset demo seed
app.post('/api/system/reset-demo', authMiddleware, (req: Request, res: Response) => {
  const user = (req as any).user as User;
  if (user.role !== 'admin') {
    return res.status(403).json({ error: '只有系統管理員可以重置示範資料庫' });
  }

  const initial = getInitialDatabase();
  writeDB(initial);
  res.json({ success: true, message: '系統示範資料庫已重置完成' });
});

// -------------------------------------------------------------
// Vite Middleware / Static Server
// -------------------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Warehouse WMS Server] running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
